#!/usr/bin/env python3
"""
CVE Research Helper for SFTPD/SFTP service analysis.

Searches NVD API for known vulnerabilities related to a service name/version.
Intended for use in authorized security assessments only.

Usage:
    python3 cve_search.py --service "SFTPD" --version "1.3.5"
    python3 cve_search.py --service "OpenSSH" --version "8.0"
"""

import argparse
import json
import sys
import urllib.request
import urllib.parse
from datetime import datetime


NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"


def search_cves(keyword: str, version: str = "", max_results: int = 20) -> dict:
    """Search NVD for CVEs matching the keyword."""
    params = {
        "keywordSearch": keyword,
        "resultsPerPage": str(max_results),
    }
    if version:
        params["keywordSearch"] = f"{keyword} {version}"

    url = f"{NVD_API}?{urllib.parse.urlencode(params)}"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "CVE-Research-Helper/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
    except Exception as e:
        return {"error": str(e), "vulnerabilities": []}

    results = []
    for item in data.get("vulnerabilities", []):
        cve = item.get("cve", {})
        cve_id = cve.get("id", "")
        descriptions = cve.get("descriptions", [])
        desc = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")

        # Get CVSS score
        metrics = cve.get("metrics", {})
        cvss_v31 = metrics.get("cvssMetricV31", [{}])
        cvss_v2 = metrics.get("cvssMetricV2", [{}])

        score = "N/A"
        severity = "N/A"
        if cvss_v31:
            cvss_data = cvss_v31[0].get("cvssData", {})
            score = cvss_data.get("baseScore", "N/A")
            severity = cvss_data.get("baseSeverity", "N/A")
        elif cvss_v2:
            cvss_data = cvss_v2[0].get("cvssData", {})
            score = cvss_data.get("baseScore", "N/A")
            severity = cvss_v2.get("baseSeverity", "N/A")

        # Published date
        published = cve.get("published", "")[:10]

        results.append({
            "cve_id": cve_id,
            "description": desc[:200],
            "score": score,
            "severity": severity,
            "published": published,
            "references": [r.get("url", "") for r in cve.get("references", [])[:3]],
        })

    return {
        "query": keyword,
        "version": version,
        "total": data.get("totalResults", 0),
        "returned": len(results),
        "searched_at": datetime.utcnow().isoformat(),
        "vulnerabilities": results,
    }


def main():
    parser = argparse.ArgumentParser(description="CVE Research Helper (NVD API)")
    parser.add_argument("--service", required=True, help="Service name (e.g., SFTPD, OpenSSH)")
    parser.add_argument("--version", default="", help="Version string (e.g., 1.3.5)")
    parser.add_argument("--max", type=int, default=20, help="Max results")
    parser.add_argument("--out", default="", help="Output JSON file")
    args = parser.parse_args()

    result = search_cves(args.service, args.version, args.max)

    output = json.dumps(result, ensure_ascii=False, indent=2)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"Results saved to {args.out}")
    else:
        print(output)


if __name__ == "__main__":
    main()
