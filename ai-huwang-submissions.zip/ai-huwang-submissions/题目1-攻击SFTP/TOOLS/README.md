# 题目 1 TOOLS 使用说明

本目录提供授权 SFTP 靶机安全验证所需的辅助工具和 AI 工件。

## 文件说明

```text
TOOLS/
├── authorized_sftp_recon.py        # 授权目标 SFTP/SSH banner 与基础风险识别工具
├── evidence_template.md            # 测试证据记录模板
├── sample_outputs/
│   └── sftp_recon_sample.json      # 样例输出
└── ai_artifacts/
    ├── skills/
    └── agents/
```

## 使用方式

```bash
python3 authorized_sftp_recon.py --host <授权靶机IP> --port 22 --out evidence.json
```

## 安全边界

该工具只做单目标、非破坏性服务识别，不包含密码爆破、漏洞利用、提权、持久化、数据下载等能力。仅可在比赛授权靶机或自有测试环境中使用。
