#!/usr/bin/env python3
"""
Authorized SFTP reconnaissance helper.

Purpose:
- Identify SSH/SFTP banner on an explicitly authorized single target.
- Produce JSON evidence for a competition report.

Safety boundaries:
- No password guessing.
- No exploit execution.
- No destructive action.
- No network range scanning.
"""

import argparse
import json
import socket
import ssl
from datetime import datetime, timezone


def grab_banner(host: str, port: int, timeout: float) -> str:
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        try:
            banner = sock.recv(256).decode("utf-8", errors="replace").strip()
        except socket.timeout:
            banner = ""
    return banner


def analyze_banner(banner: str):
    findings = []
    service_guess = "unknown"

    if banner.startswith("SSH-"):
        service_guess = "ssh/sftp"
        findings.append({
            "id": "SSH_SERVICE_EXPOSED",
            "severity": "info",
            "description": "目标端口返回 SSH banner，疑似提供 SSH/SFTP 服务。",
            "recommendation": "确认该服务是否必须对当前网络开放，建议结合防火墙或堡垒机限制访问来源。"
        })

    lowered = banner.lower()
    if "sftpd" in lowered or "1.3.5e" in lowered:
        findings.append({
            "id": "SFTPD_VERSION_EXPOSED",
            "severity": "medium",
            "description": "服务 banner 暴露 SFTPD 或具体版本信息，可能辅助攻击者进行漏洞匹配。",
            "recommendation": "建议升级到安全版本，并尽量隐藏或模糊不必要的版本信息。"
        })

    if "openssh" in lowered:
        findings.append({
            "id": "OPENSSH_BANNER_EXPOSED",
            "severity": "low",
            "description": "服务暴露 OpenSSH 版本信息。",
            "recommendation": "核对 OpenSSH 是否为受支持版本，及时安装安全补丁。"
        })

    if not banner:
        findings.append({
            "id": "NO_BANNER",
            "severity": "info",
            "description": "未获取到 banner，可能是网络超时、服务未响应或服务端延迟发送。",
            "recommendation": "人工确认目标端口开放状态和网络连通性。"
        })

    return service_guess, findings


def main():
    parser = argparse.ArgumentParser(description="Authorized single-target SFTP/SSH reconnaissance helper")
    parser.add_argument("--host", required=True, help="Authorized target host or IP")
    parser.add_argument("--port", type=int, default=22, help="Authorized target port, default: 22")
    parser.add_argument("--timeout", type=float, default=5.0, help="Socket timeout seconds")
    parser.add_argument("--out", default="sftp_recon_result.json", help="Output JSON file")
    args = parser.parse_args()

    result = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target": args.host,
        "port": args.port,
        "authorized_use_only": True,
        "banner": "",
        "service_guess": "unknown",
        "findings": [],
        "manual_next_steps": [
            "确认测试目标属于比赛授权范围。",
            "根据 banner 和版本信息检索官方公告、CVE、发行说明。",
            "如有授权账号，验证登录失败锁定、目录隔离、上传控制和日志审计。",
            "将真实证据截图和命令输出补充到 ATT_REPORT.md。"
        ]
    }

    try:
        banner = grab_banner(args.host, args.port, args.timeout)
        service_guess, findings = analyze_banner(banner)
        result["banner"] = banner
        result["service_guess"] = service_guess
        result["findings"] = findings
    except Exception as exc:
        result["error"] = str(exc)
        result["findings"].append({
            "id": "CONNECTION_FAILED",
            "severity": "info",
            "description": "连接目标失败，可能是端口未开放、网络不可达或服务拒绝连接。",
            "recommendation": "检查靶机地址、端口、防火墙和比赛网络环境。"
        })

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
