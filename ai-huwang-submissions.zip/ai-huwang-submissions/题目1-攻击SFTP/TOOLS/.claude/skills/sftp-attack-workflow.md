---
name: sftp-attack-workflow
description: SFTP 授权攻击验证工作流，从信息收集到报告生成
---

# SFTP 攻击验证工作流

## 触发条件

当需要对授权 SFTP 靶机进行安全验证时使用。

## 步骤

### Step 1: 信息收集

```bash
python3 authorized_sftp_recon.py --host <靶机IP> --port 22 --out evidence.json
```

记录：
- SSH banner
- 服务版本
- 初步风险点

### Step 2: CVE 情报检索

根据识别出的版本号，在以下来源检索：
- NVD (https://nvd.nist.gov)
- CVE Details
- 官方发行说明
- GitHub Issues

### Step 3: 配置审计

如果能获取到配置文件或源码，检查：
- 认证方式和强度
- 目录隔离（chroot）
- 文件权限配置
- 日志记录完整性
- 异常处理逻辑

### Step 4: 非破坏性验证

对每个发现的风险设计验证方案：
- 仅使用授权账号
- 不执行破坏性操作
- 记录所有输入和输出
- 截图保存证据

### Step 5: 报告生成

使用 `evidence_template.md` 记录证据，生成 ATT_REPORT.md。

## 输出

- `evidence.json` — 结构化证据
- `ATT_REPORT.md` — 完整攻击报告
- `screenshots/` — 截图证据
