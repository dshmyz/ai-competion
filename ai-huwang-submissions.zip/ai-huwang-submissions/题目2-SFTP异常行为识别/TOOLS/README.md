# 题目 2 TOOLS 使用说明

## 文件说明

```text
sftp_anomaly_detector.py   # SFTP 日志异常检测脚本
sample_sftp.log            # 样例日志
result.json                # 样例输出
ai_artifacts/              # AI skill 和 agent 说明
```

## 运行

```bash
python3 sftp_anomaly_detector.py sample_sftp.log result.json
```

## 输出

输出 JSON 中包含 `summary` 和 `anomalies` 两部分。
