#!/usr/bin/env python3
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta

SENSITIVE_KEYWORDS = ["/etc/passwd", "/etc/shadow", "/root/", ".ssh", "id_rsa", ".env", "config.php", "database.yml"]
RISKY_UPLOAD_PATHS = ["/tmp/", "/var/www/", "public", "webroot", "htdocs"]
OFF_HOUR_START = 0
OFF_HOUR_END = 6
MAX_DOWNLOADS_IN_WINDOW = 20
DOWNLOAD_WINDOW_MINUTES = 10
MAX_LOGIN_FAILURES = 5
LOGIN_FAILURE_WINDOW_MINUTES = 5


def parse_log_line(line):
    pattern = (
        r"(?P<time>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+"
        r"user=(?P<user>\S+)\s+"
        r"ip=(?P<ip>\S+)\s+"
        r"action=(?P<action>\S+)"
        r"(?:\s+file=(?P<file>\S+))?"
        r"(?:\s+size=(?P<size>\d+))?"
        r"(?:\s+status=(?P<status>\S+))?"
    )
    m = re.search(pattern, line)
    if not m:
        return None
    d = m.groupdict()
    d["datetime"] = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
    d["file"] = d.get("file") or ""
    d["status"] = d.get("status") or ""
    d["size"] = int(d["size"] or 0)
    return d


def add(anomalies, event, typ, risk, desc, sug):
    anomalies.append({
        "time": event["time"], "user": event["user"], "ip": event["ip"],
        "type": typ, "risk_level": risk, "description": desc, "suggestion": sug
    })


def detect_off_hours_login(events):
    a = []
    for e in events:
        if e["action"] == "login" and e["status"] == "success" and OFF_HOUR_START <= e["datetime"].hour < OFF_HOUR_END:
            add(a, e, "off_hours_login", "medium", f"用户 {e['user']} 在非工作时间登录 SFTP", "核实是否为本人操作，必要时重置密码并检查来源 IP")
    return a


def detect_sensitive_file_access(events):
    a = []
    for e in events:
        if e["action"] in {"download", "upload", "read"} and any(k in e["file"] for k in SENSITIVE_KEYWORDS):
            add(a, e, "sensitive_file_access", "high", f"用户 {e['user']} 访问敏感文件 {e['file']}", "立即检查账号权限、登录来源和敏感目录访问控制")
    return a


def detect_risky_upload_path(events):
    a = []
    for e in events:
        if e["action"] == "upload" and any(k in e["file"] for k in RISKY_UPLOAD_PATHS):
            add(a, e, "risky_upload_path", "medium", f"用户 {e['user']} 上传文件到高风险路径 {e['file']}", "检查上传目录权限，禁止上传目录执行脚本，必要时隔离该文件")
    return a


def detect_mass_download(events):
    a = []
    downloads = defaultdict(list)
    for e in events:
        if e["action"] == "download":
            downloads[e["user"]].append(e)
    for user, rows in downloads.items():
        rows.sort(key=lambda x: x["datetime"])
        left = 0
        for right in range(len(rows)):
            while rows[right]["datetime"] - rows[left]["datetime"] > timedelta(minutes=DOWNLOAD_WINDOW_MINUTES):
                left += 1
            if right - left + 1 > MAX_DOWNLOADS_IN_WINDOW:
                e = rows[right]
                add(a, e, "mass_download", "high", f"用户 {user} 在 {DOWNLOAD_WINDOW_MINUTES} 分钟内下载文件数量超过 {MAX_DOWNLOADS_IN_WINDOW}", "检查下载内容是否涉及敏感数据，并限制批量下载行为")
                break
    return a


def detect_multiple_login_failures(events):
    a = []
    failures = defaultdict(list)
    for e in events:
        if e["action"] == "login" and e["status"] == "failed":
            failures[e["ip"]].append(e)
    for ip, rows in failures.items():
        rows.sort(key=lambda x: x["datetime"])
        left = 0
        for right in range(len(rows)):
            while rows[right]["datetime"] - rows[left]["datetime"] > timedelta(minutes=LOGIN_FAILURE_WINDOW_MINUTES):
                left += 1
            if right - left + 1 >= MAX_LOGIN_FAILURES:
                e = rows[right]
                add(a, e, "multiple_login_failures", "high", f"IP {ip} 在短时间内多次登录失败，疑似暴力破解", "封禁该 IP，启用登录失败锁定策略，并检查账号安全")
                break
    return a


def detect_new_ip_login(events):
    if len(events) < 10:
        return []
    split = int(len(events) * 0.7)
    known = defaultdict(set)
    for e in events[:split]:
        if e["action"] == "login" and e["status"] == "success":
            known[e["user"]].add(e["ip"])
    a = []
    for e in events[split:]:
        if e["action"] == "login" and e["status"] == "success" and known[e["user"]] and e["ip"] not in known[e["user"]]:
            add(a, e, "new_ip_login", "medium", f"用户 {e['user']} 从历史未出现过的新 IP {e['ip']} 登录", "核实登录来源，检查是否存在账号泄露风险")
    return a


def analyze(path):
    events = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            e = parse_log_line(line.strip())
            if e:
                events.append(e)
    events.sort(key=lambda x: x["datetime"])
    anomalies = []
    for fn in [detect_off_hours_login, detect_sensitive_file_access, detect_risky_upload_path, detect_mass_download, detect_multiple_login_failures, detect_new_ip_login]:
        anomalies.extend(fn(events))
    return {
        "summary": {
            "total_events": len(events),
            "users": len({e["user"] for e in events}),
            "ips": len({e["ip"] for e in events}),
            "actions": dict(Counter(e["action"] for e in events)),
            "anomalies": len(anomalies),
        },
        "anomalies": anomalies,
    }


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 sftp_anomaly_detector.py <input_log> <output_json>")
        sys.exit(1)
    result = analyze(sys.argv[1])
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
