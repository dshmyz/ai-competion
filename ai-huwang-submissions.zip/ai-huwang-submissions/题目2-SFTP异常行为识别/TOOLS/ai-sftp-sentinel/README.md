# AI-SFTP Sentinel

## 基于用户行为画像与 AI 异常检测的 SFTP 安全分析平台

### 架构概览

```
已有的日志采集器 / 日志文件
              │
              ▼
     ┌─────────────────┐
     │  Log Collector   │ ← Go tail 实时采集 + 手动导入
     │  (tail_collector)│
     └────────┬────────┘
              │ SQLite
              ▼
     ┌─────────────────┐     ┌───────────────────┐
     │ Session Builder  │     │  Profile Builder   │
     │ (会话重建)        │     │  (五维画像)         │
     └────────┬────────┘     └────────┬──────────┘
              │                       │
              ▼                       ▼
     ┌─────────────────────────────────────────┐
     │          Detector Engine                 │
     │  ┌──────────────┐  ┌─────────────────┐  │
     │  │  Rule Engine  │  │ Isolation Forest │  │
     │  │  (7 条规则)    │  │  (Go 原生实现)    │  │
     │  └──────┬───────┘  └────────┬────────┘  │
     │         └─────────┬─────────┘           │
     │                   ▼                      │
     │            Risk Scoring                  │
     │                   │                      │
     │                   ▼                      │
     │         LLM Explain (Ollama)            │
     └─────────────────────┬───────────────────┘
                           │
                           ▼
                    Vue3 Dashboard
```

### 技术栈

| 组件 | 技术 |
|---|---|
| 后端 | Go 1.21+ / Gin / GORM / SQLite |
| AI 检测 | Go 原生 Isolation Forest |
| AI 解释 | Go → Ollama HTTP API (Qwen3) |
| 前端 | Vue 3 / Element Plus / ECharts |
| 日志采集 | Go tail 实时采集 |

**无 Python 依赖，单二进制部署。**

### 核心模块

| 模块 | 文件 | 功能 |
|---|---|---|
| 日志解析 | `parser/sftp_parser.go` | 支持 OpenSSH / key=value / auditd 三种格式 |
| 日志采集 | `logcollector/tail_collector.go` | 实时 tail + 断点续读 + 日志轮转 |
| Session 重建 | `sessionbuilder/builder.go` | PID + 用户 + 30min 时间窗口关联 |
| 用户画像 | `services/profile_builder.go` | 时间/IP/路径/文件/流量五维基线 |
| 规则检测 | `services/detector.go` | 7 条检测规则，风险分 0-100 |
| 异常检测 | `services/anomaly_forest.go` | Go 原生 Isolation Forest |
| LLM 解释 | `services/llm_client.go` | Ollama HTTP 调用 + 模板回退 |
| 风险评分 | `services/risk_scorer.go` | 规则分 + AI 分 → 综合评分 |

### 快速启动

```bash
cd scripts
./start.sh ../data/sample.log
# 浏览器访问 http://localhost:3000
```

### API 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | /api/dashboard | 仪表盘统计 |
| GET | /api/alerts | 告警列表 |
| GET | /api/users | 用户画像列表 |
| GET | /api/events | 事件日志 |
| POST | /api/import | 导入日志文件 |
| POST | /api/analyze/run-all | 一键完整分析 |
| POST | /api/forest/train | 重训 Isolation Forest |
| GET | /api/ai/stats | AI 模型状态 |
