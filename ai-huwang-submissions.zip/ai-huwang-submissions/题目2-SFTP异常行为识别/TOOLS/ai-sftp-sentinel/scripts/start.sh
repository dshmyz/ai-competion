#!/bin/bash
# AI-SFTP Sentinel startup script
# Usage: ./start.sh [log_file_to_watch]
# Example: ./start.sh /var/log/auth.log
# Example: ./start.sh ../data/sample.log

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR/.."
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"
LOG_FILE="${1:-}"

echo "============================================"
echo "  AI-SFTP Sentinel"
echo "  基于用户行为画像与AI异常检测的SFTP安全分析平台"
echo "============================================"

# Build Go backend
echo ""
echo "[1/2] 编译 Go 后端..."
cd "$BACKEND_DIR"
if [ ! -f "go.sum" ]; then
    echo "  下载 Go 依赖..."
    go mod tidy
fi

LOG_FILES_FLAG=""
if [ -n "$LOG_FILE" ] && [ -f "$LOG_FILE" ]; then
    ABS_LOG="$(cd "$(dirname "$LOG_FILE")" && pwd)/$(basename "$LOG_FILE")"
    export LOG_FILES="$ABS_LOG"
    echo "  监控日志: $ABS_LOG"
fi

echo "  启动后端 (port 8080)..."
go run main.go &
BACKEND_PID=$!
sleep 2

# Import seed data if provided
if [ -n "$LOG_FILE" ] && [ -f "$LOG_FILE" ]; then
    echo ""
    echo "[可选] 导入日志数据..."
    curl -s -X POST http://localhost:8080/api/import \
        -H "Content-Type: application/json" \
        -d "{\"path\": \"$ABS_LOG\"}" | python3 -m json.tool 2>/dev/null || true

    echo "  构建会话..."
    curl -s -X POST http://localhost:8080/api/sessions/build | python3 -m json.tool 2>/dev/null || true
    echo "  构建画像..."
    curl -s -X POST http://localhost:8080/api/profiles/build | python3 -m json.tool 2>/dev/null || true
    echo "  运行检测..."
    curl -s -X POST http://localhost:8080/api/detect | python3 -m json.tool 2>/dev/null || true
fi

# Start frontend
echo ""
echo "[2/2] 启动前端..."
cd "$FRONTEND_DIR"
if [ ! -d "node_modules" ]; then
    npm install
fi
npm run dev &
FRONTEND_PID=$!

echo ""
echo "============================================"
echo "  服务已启动:"
echo "    后端 API:  http://localhost:8080"
echo "    前端界面:  http://localhost:3000"
echo ""
echo "  按 Ctrl+C 停止所有服务"
echo "============================================"

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null" EXIT INT TERM
wait
