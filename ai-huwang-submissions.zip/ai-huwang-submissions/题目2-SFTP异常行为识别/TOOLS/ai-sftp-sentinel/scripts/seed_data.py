#!/usr/bin/env python3
"""
Seed script: generate realistic SFTP log data for demonstration.

Usage:
    python seed_data.py [output_file] [num_events]

Output:
    Generates a structured key=value SFTP log file.
"""

import sys
import random
from datetime import datetime, timedelta

USERS = ["alice", "bob", "charlie", "diana", "admin"]
NORMAL_IPS = {
    "alice": ["192.168.1.10", "192.168.1.11"],
    "bob": ["192.168.1.20"],
    "charlie": ["192.168.1.30"],
    "diana": ["192.168.1.40", "10.0.0.50"],
    "admin": ["10.0.0.1"],
}
NORMAL_DIRS = {
    "alice": ["/upload/alice", "/report/weekly"],
    "bob": ["/upload/bob", "/data/export"],
    "charlie": ["/shared/team-b", "/upload/charlie"],
    "diana": ["/finance/reports", "/shared/team-a"],
    "admin": ["/config", "/logs"],
}
NORMAL_EXTS = [".xlsx", ".pdf", ".csv", ".txt", ".docx", ".zip"]
ANOMALOUS_EXTS = [".exe", ".dll", ".sh", ".py", ".sql", ".bak"]
SENSITIVE_FILES = ["/etc/passwd", "/etc/shadow", "/root/.ssh/id_rsa", "/config/database.yml", "/.env"]

def generate_normal_events(base_time, user, count):
    events = []
    for i in range(count):
        t = base_time + timedelta(minutes=random.randint(1, 30))
        ip = random.choice(NORMAL_IPS[user])
        action = random.choices(["login", "download", "upload", "download", "download"], weights=[2, 5, 3, 5, 3])[0]

        if action == "login":
            events.append(f"{t} user={user} ip={ip} action=login status=success")
        else:
            directory = random.choice(NORMAL_DIRS[user])
            ext = random.choice(NORMAL_EXTS)
            fname = f"{directory}/file_{random.randint(1000,9999)}{ext}"
            size = random.randint(1024, 5 * 1024 * 1024)
            events.append(f"{t} user={user} ip={ip} action={action} file={fname} size={size}")
        base_time = t
    return events, base_time

def generate_anomaly_events(base_time):
    """Generate various anomalous events."""
    anomalies = []

    # 1. Off-hours login + sensitive file access by bob
    t1 = base_time.replace(hour=2, minute=31, second=44) + timedelta(days=1)
    anomalies.append(f"{t1} user=bob ip=45.77.12.88 action=login status=success")
    t1 += timedelta(seconds=26)
    anomalies.append(f"{t1} user=bob ip=45.77.12.88 action=download file=/etc/passwd size=4096")
    t1 += timedelta(seconds=15)
    anomalies.append(f"{t1} user=bob ip=45.77.12.88 action=download file=/etc/shadow size=2048")

    # 2. Brute force from external IP
    t2 = base_time.replace(hour=11, minute=1, second=0) + timedelta(days=1)
    for i in range(6):
        anomalies.append(f"{t2} user=admin ip=103.21.45.9 action=login status=failed")
        t2 += timedelta(seconds=random.randint(15, 30))

    # 3. Mass download by alice (exfiltration simulation)
    t3 = base_time.replace(hour=14, minute=0, second=0) + timedelta(days=1)
    anomalies.append(f"{t3} user=alice ip=192.168.1.10 action=login status=success")
    for i in range(25):
        t3 += timedelta(seconds=random.randint(10, 30))
        fname = f"/finance/confidential/report_{i:03d}.xlsx"
        size = random.randint(1024 * 1024, 10 * 1024 * 1024)
        anomalies.append(f"{t3} user=alice ip=192.168.1.10 action=download file={fname} size={size}")

    # 4. Upload to web root by charlie
    t4 = base_time.replace(hour=14, minute=20, second=1) + timedelta(days=1)
    anomalies.append(f"{t4} user=charlie ip=192.168.1.30 action=upload file=/var/www/html/shell.php size=4096")
    t4 += timedelta(minutes=2)
    anomalies.append(f"{t4} user=charlie ip=192.168.1.30 action=upload file=/var/www/html/backdoor.sh size=2048")

    # 5. New IP login for diana
    t5 = base_time.replace(hour=16, minute=45, second=0) + timedelta(days=1)
    anomalies.append(f"{t5} user=diana ip=203.0.113.50 action=login status=success")
    t5 += timedelta(minutes=5)
    anomalies.append(f"{t5} user=diana ip=203.0.113.50 action=download file=/finance/reports/annual_2026.xlsx size=8388608")

    # 6. SQL dump download by admin
    t6 = base_time.replace(hour=23, minute=55, second=0) + timedelta(days=1)
    anomalies.append(f"{t6} user=admin ip=10.0.0.1 action=login status=success")
    t6 += timedelta(minutes=3)
    anomalies.append(f"{t6} user=admin ip=10.0.0.1 action=download file=/backup/full_dump.sql size=524288000")
    t6 += timedelta(minutes=2)
    anomalies.append(f"{t6} user=admin ip=10.0.0.1 action=download file=/config/database.yml size=1024")

    return anomalies

def main():
    output = sys.argv[1] if len(sys.argv) > 1 else "sample_sftp_full.log"
    num_days = int(sys.argv[2]) if len(sys.argv) > 2 else 7

    all_events = []
    base = datetime(2026, 5, 14, 8, 0, 0)

    for day in range(num_days):
        day_base = base + timedelta(days=day)
        for user in USERS:
            count = random.randint(8, 25)
            events, _ = generate_normal_events(day_base + timedelta(hours=random.randint(8, 16)), user, count)
            all_events.extend(events)

    # Add anomalies on the last 2 days
    all_events.extend(generate_anomaly_events(base + timedelta(days=num_days - 2)))
    all_events.extend(generate_anomaly_events(base + timedelta(days=num_days - 1)))

    # Sort by timestamp
    all_events.sort()

    with open(output, "w") as f:
        for line in all_events:
            f.write(line + "\n")

    print(f"Generated {len(all_events)} events -> {output}")

if __name__ == "__main__":
    main()
