package sessionbuilder

import (
	"fmt"
	"time"

	"ai-sftp-sentinel/models"

	"gorm.io/gorm"
)

type Builder struct {
	db *gorm.DB
}

func New(db *gorm.DB) *Builder {
	return &Builder{db: db}
}

// BuildSessions reconstructs sessions from events using PID/IP/time-window heuristics.
// Events are grouped by (user, IP) within a time window.
func (b *Builder) BuildSessions() (int, error) {
	var events []models.Event
	b.db.Order("user ASC, time ASC").Find(&events)

	if len(events) == 0 {
		return 0, nil
	}

	// Clear existing sessions for rebuild
	b.db.Exec("DELETE FROM sessions")

	sessionGap := 30 * time.Minute
	var sessions []models.Session

	current := models.Session{
		ID:        fmt.Sprintf("s-%d", 1),
		User:      events[0].User,
		IP:        events[0].IP,
		LoginTime: events[0].Time,
	}
	sid := 1

	for i := 0; i < len(events); i++ {
		ev := events[i]

		// Start new session if user/IP changes or gap too large
		needsNewSession := false
		if ev.User != current.User || ev.IP != current.IP {
			needsNewSession = true
		} else if ev.Time.Sub(current.LoginTime) > sessionGap && current.EventCount > 0 {
			needsNewSession = true
		}

		if needsNewSession {
			// Finalize current session
			sessions = append(sessions, current)
			sid++
			current = models.Session{
				ID:        fmt.Sprintf("s-%d", sid),
				User:      ev.User,
				IP:        ev.IP,
				LoginTime: ev.Time,
			}
		}

		// Update session
		current.EventCount++
		if ev.Action == "UPLOAD" {
			current.TotalUpload += ev.Size
		} else if ev.Action == "DOWNLOAD" {
			current.TotalDownload += ev.Size
		}

		// Update logout time
		if ev.Action == "LOGOUT" || ev.Action == "LOGIN" {
			current.LogoutTime = &ev.Time
		}

		// Assign session ID to event
		b.db.Model(&models.Event{}).Where("id = ?", ev.ID).Update("session_id", current.ID)
	}

	// Don't forget the last session
	sessions = append(sessions, current)

	// Batch insert sessions
	if len(sessions) > 0 {
		b.db.CreateInBatches(sessions, 500)
	}

	return len(sessions), nil
}
