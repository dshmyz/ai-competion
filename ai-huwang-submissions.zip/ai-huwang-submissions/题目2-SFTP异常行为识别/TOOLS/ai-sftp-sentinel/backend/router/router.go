package router

import (
	"time"

	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/handlers"
	"ai-sftp-sentinel/services"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func Setup(db *gorm.DB, cfg *config.Config, scorer *services.RiskScorer) *gin.Engine {
	r := gin.Default()

	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Authorization"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	h := handlers.New(db, cfg, scorer)

	api := r.Group("/api")
	{
		api.GET("/dashboard", h.GetDashboard)

		api.GET("/alerts", h.GetAlerts)
		api.GET("/alerts/top", h.GetTopAlerts)

		api.GET("/users", h.GetUsers)
		api.GET("/users/:user/profile", h.GetUserProfile)
		api.GET("/users/:user/events", h.GetUserEvents)

		api.GET("/events", h.GetEvents)
		api.GET("/sessions", h.GetSessions)

		api.POST("/import", h.ImportLog)
		api.POST("/collect", h.TriggerCollect)
		api.POST("/sessions/build", h.BuildSessions)
		api.POST("/profiles/build", h.BuildProfiles)
		api.POST("/detect", h.RunDetection)
		api.POST("/analyze/run-all", h.RunFullAnalysis)
		api.POST("/forest/train", h.TrainForest)

		api.GET("/ai/stats", h.GetAIStats)
	}

	return r
}
