package services

import (
	"math"
	"math/rand"
)

// IsolationForest is a simplified implementation of the Isolation Forest algorithm.
//
// Core idea: anomalies are isolated faster (shorter average path length) than
// normal points, because they sit in sparse regions of the feature space.
//
// This implementation builds random binary trees where each internal node
// splits on a random feature at a random value. The anomaly score is derived
// from the average path length across all trees.
type IsolationForest struct {
	Trees        []*IsolationTree
	NumTrees     int
	SampleSize   int
	NumFeatures  int
	TrainingData [][]float64
}

// IsolationTree is a single random tree.
type IsolationTree struct {
	Root *TreeNode
}

// TreeNode represents a node in an isolation tree.
type TreeNode struct {
	// Internal node fields
	SplitFeature int
	SplitValue   float64
	Left         *TreeNode
	Right        *TreeNode

	// Leaf node fields
	IsLeaf   bool
	Size     int // number of training samples that ended up here
	Depth    int
}

// NewIsolationForest creates a new Isolation Forest model.
func NewIsolationForest(numTrees, sampleSize int) *IsolationForest {
	return &IsolationForest{
		NumTrees:   numTrees,
		SampleSize: sampleSize,
	}
}

// Train builds the isolation forest from training data.
// Each tree is trained on a subsample of the data.
func (f *IsolationForest) Train(data [][]float64) {
	f.TrainingData = data
	if len(data) == 0 {
		return
	}
	f.NumFeatures = len(data[0])
	f.Trees = make([]*IsolationTree, f.NumTrees)

	for i := 0; i < f.NumTrees; i++ {
		sample := f.subsample(data)
		f.Trees[i] = &IsolationTree{
			Root: f.buildTree(sample, 0, maxDepth(f.SampleSize)),
		}
	}
}

// Predict returns the anomaly score for a single point.
// Score is in [0, 1]; higher = more anomalous.
func (f *IsolationForest) Predict(point []float64) float64 {
	if len(f.Trees) == 0 {
		return 0.5
	}

	totalPath := 0.0
	for _, tree := range f.Trees {
		totalPath += float64(f.pathLength(point, tree.Root))
	}
	avgPath := totalPath / float64(len(f.Trees))

	// Normalize using the expected path length of unsuccessful search in BST
	n := float64(f.SampleSize)
	cn := 2.0*(math.Log(n-1)+0.5772156649) - 2.0*(n-1)/n // Euler-Mascheroni constant

	if cn <= 0 {
		return 0.5
	}

	// Score = 2^(-avgPath / cn)
	// Score close to 1 = anomaly, close to 0 = normal
	score := math.Pow(2, -avgPath/cn)
	return score
}

// PredictBatch returns anomaly scores for multiple points.
func (f *IsolationForest) PredictBatch(data [][]float64) []float64 {
	scores := make([]float64, len(data))
	for i, point := range data {
		scores[i] = f.Predict(point)
	}
	return scores
}

// subsample draws a random sample without replacement.
func (f *IsolationForest) subsample(data [][]float64) [][]float64 {
	n := len(data)
	if n <= f.SampleSize {
		result := make([][]float64, n)
		copy(result, data)
		return result
	}

	// Fisher-Yates shuffle of indices
	indices := make([]int, n)
	for i := range indices {
		indices[i] = i
	}
	for i := n - 1; i > 0; i-- {
		j := rand.Intn(i + 1)
		indices[i], indices[j] = indices[j], indices[i]
	}

	result := make([][]float64, f.SampleSize)
	for i := 0; i < f.SampleSize; i++ {
		result[i] = data[indices[i]]
	}
	return result
}

// buildTree recursively builds an isolation tree.
func (f *IsolationForest) buildTree(data [][]float64, depth, maxDepth int) *TreeNode {
	if len(data) <= 1 || depth >= maxDepth {
		return &TreeNode{IsLeaf: true, Size: len(data), Depth: depth}
	}

	// Pick a random feature
	feature := rand.Intn(f.NumFeatures)

	// Find min and max of this feature
	minVal, maxVal := data[0][feature], data[0][feature]
	for _, row := range data {
		if row[feature] < minVal {
			minVal = row[feature]
		}
		if row[feature] > maxVal {
			maxVal = row[feature]
		}
	}

	if minVal == maxVal {
		return &TreeNode{IsLeaf: true, Size: len(data), Depth: depth}
	}

	// Pick a random split value in [minVal, maxVal)
	splitVal := minVal + rand.Float64()*(maxVal-minVal)

	// Partition data
	var left, right [][]float64
	for _, row := range data {
		if row[feature] < splitVal {
			left = append(left, row)
		} else {
			right = append(right, row)
		}
	}

	if len(left) == 0 || len(right) == 0 {
		return &TreeNode{IsLeaf: true, Size: len(data), Depth: depth}
	}

	return &TreeNode{
		SplitFeature: feature,
		SplitValue:   splitVal,
		Left:         f.buildTree(left, depth+1, maxDepth),
		Right:        f.buildTree(right, depth+1, maxDepth),
	}
}

// pathLength computes the path length of a point in a tree.
func (f *IsolationForest) pathLength(point []float64, node *TreeNode) int {
	if node.IsLeaf {
		// Add expected path length adjustment for leaf size
		return node.Depth + estimateCn(node.Size)
	}

	if point[node.SplitFeature] < node.SplitValue {
		return f.pathLength(point, node.Left)
	}
	return f.pathLength(point, node.Right)
}

// estimateCn estimates the average path length of unsuccessful search in BST.
func estimateCn(n int) float64 {
	if n <= 1 {
		return 0
	}
	return 2.0*(math.Log(float64(n)-1)+0.5772156649) - 2.0*float64(n-1)/float64(n)
}

func maxDepth(sampleSize int) int {
	return int(math.Ceil(math.Log2(float64(sampleSize))))
}

// FeatureNames returns the names of the features used.
func FeatureNames() []string {
	return []string{
		"login_hour_deviation",
		"is_new_ip",
		"is_new_path",
		"is_new_ext",
		"upload_deviation",
		"download_deviation",
		"transfer_deviation",
		"login_fail_ratio",
		"session_duration",
		"event_density",
	}
}

// BuildFeatures constructs a feature vector from profile and current events.
func BuildFeatures(profile *Profile, events []Event) []float64 {
	if len(events) == 0 {
		return make([]float64, 10)
	}

	features := make([]float64, 10)

	// 1. Login hour deviation
	hour := events[0].Time.Hour()
	activeCenter := float64(profile.ActiveStart+profile.ActiveEnd) / 2.0
	features[0] = math.Min(math.Abs(float64(hour)-activeCenter)/12.0, 1.0)

	// 2. Is new IP
	knownIPs := parseJSONArray(profile.KnownIPs)
	isNewIP := 1.0
	for _, ip := range knownIPs {
		if ip == events[0].IP {
			isNewIP = 0.0
			break
		}
	}
	if len(knownIPs) == 0 {
		isNewIP = 0.0
	}
	features[1] = isNewIP

	// 3. Is new path
	favPaths := parseJSONArray(profile.FavoritePaths)
	newPath := 0.0
	for _, ev := range events {
		if ev.Path != "" {
			dir := dirName(ev.Path)
			found := false
			for _, p := range favPaths {
				if dir == p {
					found = true
					break
				}
			}
			if !found && len(favPaths) > 0 {
				newPath = 1.0
				break
			}
		}
	}
	features[2] = newPath

	// 4. Is new file extension
	favExts := parseJSONArray(profile.FavoriteExts)
	newExt := 0.0
	for _, ev := range events {
		if ev.Path != "" {
			ext := fileExt(ev.Path)
			if ext != "" {
				found := false
				for _, e := range favExts {
					if ext == e {
						found = true
						break
					}
				}
				if !found && len(favExts) > 0 {
					newExt = 1.0
					break
				}
			}
		}
	}
	features[3] = newExt

	// 5-7. Transfer deviations
	var uploadTotal, downloadTotal int64
	for _, ev := range events {
		switch ev.Action {
		case "UPLOAD":
			uploadTotal += ev.Size
		case "DOWNLOAD":
			downloadTotal += ev.Size
		}
	}

	avgUploadBytes := profile.AvgUpload * 1024 * 1024
	avgDownloadBytes := profile.AvgDownload * 1024 * 1024
	avgTransferBytes := avgUploadBytes + avgDownloadBytes

	if avgUploadBytes > 0 {
		features[4] = math.Min(float64(uploadTotal)/avgUploadBytes/10.0, 1.0)
	}
	if avgDownloadBytes > 0 {
		features[5] = math.Min(float64(downloadTotal)/avgDownloadBytes/10.0, 1.0)
	}
	if avgTransferBytes > 0 {
		features[6] = math.Min(float64(uploadTotal+downloadTotal)/avgTransferBytes/10.0, 1.0)
	}

	// 8. Login fail ratio
	failCount := 0
	for _, ev := range events {
		if ev.Status == "failed" {
			failCount++
		}
	}
	features[7] = float64(failCount) / math.Max(float64(len(events)), 1)

	// 9. Session duration (normalized to [0,1])
	if len(events) > 1 {
		duration := events[len(events)-1].Time.Sub(events[0].Time).Hours()
		features[8] = math.Min(duration/8.0, 1.0)
	}

	// 10. Event density (events per minute)
	if len(events) > 1 {
		durationMin := events[len(events)-1].Time.Sub(events[0].Time).Minutes()
		if durationMin > 0 {
			features[9] = math.Min(float64(len(events))/durationMin/10.0, 1.0)
		}
	}

	return features
}

func dirName(path string) string {
	for i := len(path) - 1; i >= 0; i-- {
		if path[i] == '/' {
			return path[:i]
		}
	}
	return path
}

func fileExt(path string) string {
	for i := len(path) - 1; i >= 0; i-- {
		if path[i] == '.' {
			return path[i:]
		}
		if path[i] == '/' {
			return ""
		}
	}
	return ""
}

func parseJSONArray(s string) []string {
	if s == "" || s == "null" {
		return nil
	}
	// Simple JSON array parser: ["a","b","c"]
	s = trimSpace(s)
	if len(s) < 2 || s[0] != '[' || s[len(s)-1] != ']' {
		return nil
	}
	inner := s[1 : len(s)-1]
	if inner == "" {
		return nil
	}

	var result []string
	current := ""
	inQuote := false
	for i := 0; i < len(inner); i++ {
		ch := inner[i]
		if ch == '"' {
			inQuote = !inQuote
		} else if ch == ',' && !inQuote {
			if current != "" {
				result = append(result, trimSpace(current))
			}
			current = ""
		} else {
			current += string(ch)
		}
	}
	if current != "" {
		result = append(result, trimSpace(current))
	}
	return result
}

func trimSpace(s string) string {
	start, end := 0, len(s)
	for start < end && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n') {
		start++
	}
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n') {
		end--
	}
	return s[start:end]
}
