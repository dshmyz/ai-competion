package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"
)

// LLMClient calls a local Ollama-compatible LLM for anomaly explanation.
type LLMClient struct {
	BaseURL string
	Model   string
	Timeout time.Duration
}

func NewLLMClient(baseURL, model string) *LLMClient {
	if baseURL == "" {
		baseURL = "http://localhost:11434"
	}
	if model == "" {
		model = "qwen3:8b"
	}
	return &LLMClient{
		BaseURL: baseURL,
		Model:   model,
		Timeout: 30 * time.Second,
	}
}

// Explain sends anomaly context to the LLM and returns a structured explanation.
func (c *LLMClient) Explain(user string, profile *Profile, events []Event, features []float64, ruleScore int) (riskLevel, explanation string, suggestions []string) {
	prompt := c.buildPrompt(user, profile, events, features, ruleScore)

	client := &http.Client{Timeout: c.Timeout}
	body, _ := json.Marshal(map[string]interface{}{
		"model":  c.Model,
		"prompt": prompt,
		"stream": false,
	})

	resp, err := client.Post(c.BaseURL+"/api/generate", "application/json", bytes.NewReader(body))
	if err != nil {
		log.Printf("[llm] call failed: %v, using template fallback", err)
		return c.templateExplain(user, profile, events, features, ruleScore)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	var result struct {
		Response string `json:"response"`
	}
	if err := json.Unmarshal(respBody, &result); err != nil {
		return c.templateExplain(user, profile, events, features, ruleScore)
	}

	// Parse the LLM response
	text := result.Response
	// Remove <think>...</think> blocks (Qwen3 thinking tags)
	for {
		start := strings.Index(text, "<think>")
		if start == -1 {
			break
		}
		end := strings.Index(text[start:], "</think>")
		if end == -1 {
			text = text[:start]
			break
		}
		text = text[:start] + text[start+end+8:]
	}
	text = strings.TrimSpace(text)

	// Try to extract JSON
	riskLevel = "medium"
	explanation = text
	suggestions = []string{"持续监控该用户行为"}

	// Look for JSON block
	jsonStart := strings.Index(text, "{")
	jsonEnd := strings.LastIndex(text, "}")
	if jsonStart >= 0 && jsonEnd > jsonStart {
		jsonStr := text[jsonStart : jsonEnd+1]
		var parsed struct {
			RiskLevel   string   `json:"risk_level"`
			Explanation string   `json:"explanation"`
			Suggestions []string `json:"suggestions"`
		}
		if err := json.Unmarshal([]byte(jsonStr), &parsed); err == nil {
			if parsed.RiskLevel != "" {
				riskLevel = parsed.RiskLevel
			}
			if parsed.Explanation != "" {
				explanation = parsed.Explanation
			}
			if len(parsed.Suggestions) > 0 {
				suggestions = parsed.Suggestions
			}
		}
	}

	return riskLevel, explanation, suggestions
}

func (c *LLMClient) buildPrompt(user string, profile *Profile, events []Event, features []float64, ruleScore int) string {
	var eventLines []string
	for _, ev := range events {
		if ev.Path != "" {
			eventLines = append(eventLines, fmt.Sprintf("- %s %s %s file=%s size=%d",
				ev.Time.Format("2006-01-02 15:04:05"), ev.Action, ev.IP, ev.Path, ev.Size))
		} else {
			eventLines = append(eventLines, fmt.Sprintf("- %s %s %s status=%s",
				ev.Time.Format("2006-01-02 15:04:05"), ev.Action, ev.IP, ev.Status))
		}
		if len(eventLines) >= 10 {
			eventLines = append(eventLines, "...")
			break
		}
	}

	featureNames := []string{"登录时间偏离", "新IP", "新目录", "新文件类型", "上传偏离", "下载偏离", "传输偏离", "登录失败比", "会话时长", "事件密度"}
	var featureLines []string
	for i, name := range featureNames {
		if i < len(features) && features[i] > 0.3 {
			featureLines = append(featureLines, fmt.Sprintf("  %s: %.3f", name, features[i]))
		}
	}

	return fmt.Sprintf(`你是一名网络安全分析师。请分析以下SFTP用户行为异常，用JSON格式回答。

## 用户信息
- 用户名: %s
- 正常工作时间: %02d:00 - %02d:00
- 已知IP: %s
- 常用目录: %s
- 日均下载: %.1f MB, 日均上传: %.1f MB

## 当前异常行为（规则评分: %d）
%s

## 特征偏离
%s

请严格用JSON格式回答（不要用markdown代码块包裹）：
{"risk_level": "critical/high/medium/low", "explanation": "简明分析（200字以内）", "suggestions": ["处置建议1", "处置建议2", "处置建议3"]}`,
		user,
		profile.ActiveStart, profile.ActiveEnd,
		profile.KnownIPs, profile.FavoritePaths,
		profile.AvgDownload, profile.AvgUpload,
		ruleScore,
		strings.Join(eventLines, "\n"),
		strings.Join(featureLines, "\n"),
	)
}

// templateExplain provides a rule-based explanation when LLM is unavailable.
func (c *LLMClient) templateExplain(user string, profile *Profile, events []Event, features []float64, ruleScore int) (string, string, []string) {
	riskLevel := "medium"
	switch {
	case ruleScore >= 80:
		riskLevel = "critical"
	case ruleScore >= 60:
		riskLevel = "high"
	case ruleScore >= 30:
		riskLevel = "medium"
	default:
		riskLevel = "low"
	}

	var deviations []string
	var suggestions []string

	if features[0] > 0.5 {
		deviations = append(deviations, "登录时间偏离正常工作时段")
		suggestions = append(suggestions, "核实该时段登录是否为本人操作")
	}
	if features[1] > 0.5 {
		deviations = append(deviations, "从未知IP登录")
		suggestions = append(suggestions, "确认IP来源，检查账号是否被盗用")
	}
	if features[2] > 0.5 {
		deviations = append(deviations, "访问了历史未出现的目录")
		suggestions = append(suggestions, "检查目录访问权限配置")
	}
	if features[3] > 0.5 {
		deviations = append(deviations, "操作了历史未出现的文件类型")
		suggestions = append(suggestions, "检查是否存在恶意文件上传")
	}
	if features[4] > 0.5 {
		deviations = append(deviations, "上传量显著高于历史平均")
	}
	if features[5] > 0.5 {
		deviations = append(deviations, "下载量显著高于历史平均")
		suggestions = append(suggestions, "检查是否存在数据外泄")
	}
	if features[7] > 0.3 {
		deviations = append(deviations, "存在多次登录失败")
		suggestions = append(suggestions, "检查是否存在暴力破解")
	}

	if len(deviations) == 0 {
		deviations = append(deviations, "行为模式存在轻微偏离")
	}
	if len(suggestions) == 0 {
		suggestions = append(suggestions, "持续监控该用户行为")
	}

	explanation := fmt.Sprintf("用户 %s 当前行为与历史画像存在以下偏离：%s。",
		user, strings.Join(deviations, "；"))

	return riskLevel, explanation, suggestions
}
