package services

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
	"time"

	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/models"

	"gorm.io/gorm"
)

type Detector struct {
	db  *gorm.DB
	cfg *config.Config
}

func NewDetector(db *gorm.DB, cfg *config.Config) *Detector {
	return &Detector{db: db, cfg: cfg}
}

// RunDetection runs anomaly detection on all sessions within a time range.
func (d *Detector) RunDetection(since time.Time) (int, error) {
	var sessions []models.Session
	d.db.Where("login_time >= ?", since).Find(&sessions)

	alertCount := 0
	for _, sess := range sessions {
		alert := d.analyzeSession(sess)
		if alert != nil {
			d.db.Create(alert)
			alertCount++
		}
	}
	return alertCount, nil
}

// DetectLatest detects anomalies in recent sessions.
func (d *Detector) DetectLatest() (int, error) {
	since := time.Now().Add(-24 * time.Hour)
	return d.RunDetection(since)
}

func (d *Detector) analyzeSession(sess models.Session) *models.Alert {
	var profile models.Profile
	d.db.Where("user = ?", sess.User).First(&profile)

	var events []models.Event
	d.db.Where("session_id = ?", sess.ID).Order("time ASC").Find(&events)

	if len(events) == 0 {
		return nil // skip empty sessions
	}

	ruleScore := 0
	var reasons []string

	// Rule 1: Off-hours login
	loginHour := sess.LoginTime.Hour()
	if loginHour < d.cfg.Threshold.OffHourStart || loginHour >= d.cfg.Threshold.OffHourEnd {
		ruleScore += d.cfg.Threshold.OffHourScore
		reasons = append(reasons, fmt.Sprintf("非工作时间登录 (时间: %02d:00, 正常范围: %02d-%02d)",
			loginHour, profile.ActiveStart, profile.ActiveEnd))
	}

	// Rule 2: New IP
	if profile.KnownIPs != "" {
		var knownIPs []string
		json.Unmarshal([]byte(profile.KnownIPs), &knownIPs)
		isNewIP := true
		for _, ip := range knownIPs {
			if ip == sess.IP {
				isNewIP = false
				break
			}
		}
		if isNewIP && len(knownIPs) > 0 {
			ruleScore += d.cfg.Threshold.NewIPScore
			reasons = append(reasons, fmt.Sprintf("陌生IP登录 (IP: %s, 历史已知IP: %s)",
				sess.IP, strings.Join(knownIPs, ", ")))
		}
	}

	// Rule 3: Abnormal directory access
	if profile.FavoritePaths != "" {
		var favPaths []string
		json.Unmarshal([]byte(profile.FavoritePaths), &favPaths)
		for _, ev := range events {
			if ev.Path != "" {
				dir := filepath.Dir(ev.Path)
				isNewDir := true
				for _, p := range favPaths {
					if dir == p || strings.HasPrefix(dir, p) {
						isNewDir = false
						break
					}
				}
				if isNewDir && len(favPaths) > 0 {
					ruleScore += d.cfg.Threshold.NewDirScore
					reasons = append(reasons, fmt.Sprintf("异常目录访问 (目录: %s)", dir))
					break
				}
			}
		}
	}

	// Rule 4: Abnormal file type
	if profile.FavoriteExts != "" {
		var favExts []string
		json.Unmarshal([]byte(profile.FavoriteExts), &favExts)
		favSet := make(map[string]bool)
		for _, ext := range favExts {
			favSet[ext] = true
		}
		for _, ev := range events {
			if ev.Path != "" {
				ext := strings.ToLower(filepath.Ext(ev.Path))
				if ext != "" && !favSet[ext] {
					ruleScore += d.cfg.Threshold.NewExtScore
					reasons = append(reasons, fmt.Sprintf("异常文件类型 (类型: %s)", ext))
					break
				}
			}
		}
	}

	// Rule 5: Download/upload surge
	var sessDownload, sessUpload int64
	for _, ev := range events {
		switch ev.Action {
		case "DOWNLOAD":
			sessDownload += ev.Size
		case "UPLOAD":
			sessUpload += ev.Size
		}
	}

	sessDownloadMB := float64(sessDownload) / 1024 / 1024
	sessUploadMB := float64(sessUpload) / 1024 / 1024

	if profile.AvgDownload > 0 && sessDownloadMB > profile.AvgDownload*d.cfg.Threshold.DownloadMultiple {
		ruleScore += 20
		reasons = append(reasons, fmt.Sprintf("下载量激增 (本次: %.1fMB, 平均: %.1fMB)",
			sessDownloadMB, profile.AvgDownload))
	}

	if profile.AvgUpload > 0 && sessUploadMB > profile.AvgUpload*d.cfg.Threshold.UploadMultiple {
		ruleScore += 15
		reasons = append(reasons, fmt.Sprintf("上传量激增 (本次: %.1fMB, 平均: %.1fMB)",
			sessUploadMB, profile.AvgUpload))
	}

	// Rule 6: Multiple login failures from same IP in short time
	var failCount int64
	failWindow := time.Now().Add(-5 * time.Minute)
	d.db.Model(&models.Event{}).
		Where("ip = ? AND action = 'LOGIN' AND status = 'failed' AND time >= ?", sess.IP, failWindow).
		Count(&failCount)
	if failCount >= 5 {
		ruleScore += 25
		reasons = append(reasons, fmt.Sprintf("同IP多次登录失败 (IP: %s, 失败次数: %d)", sess.IP, failCount))
	}

	// Always create an alert entry so AI scoring can evaluate it.
	// Even if no rule fired (ruleScore==0), the AI engine may detect anomalies.

	// Cap rule score at 100
	if ruleScore > 100 {
		ruleScore = 100
	}

	totalScore := ruleScore
	if totalScore == 0 {
		// Use a minimal base score; AI enrichment will set the real score
		totalScore = 1
	}
	level := models.ScoreToLevel(totalScore)

	if len(reasons) == 0 {
		reasons = []string{"规则引擎未触发，等待 AI 分析"}
	}

	reasonsJSON, _ := json.Marshal(reasons)

	return &models.Alert{
		User:      sess.User,
		SessionID: sess.ID,
		IP:        sess.IP,
		Score:     totalScore,
		Level:     level,
		RuleScore: ruleScore,
		AIScore:   0, // Will be updated by AI service
		Reasons:   string(reasonsJSON),
		Time:      sess.LoginTime,
	}
}
