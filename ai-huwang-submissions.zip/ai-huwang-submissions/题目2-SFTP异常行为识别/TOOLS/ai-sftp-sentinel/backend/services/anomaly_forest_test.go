package services

import (
	"math"
	"testing"
	"time"
)

func TestIsolationForest_TrainAndPredict(t *testing.T) {
	forest := NewIsolationForest(50, 128)

	// Generate normal data (centered around 0.3)
	var data [][]float64
	for i := 0; i < 500; i++ {
		features := []float64{
			0.15 + float64(i%100)/1000.0,
			0.05,
			0.05,
			0.05,
			0.20 + float64(i%50)/500.0,
			0.25,
			0.20,
			0.02,
			0.30,
			0.20,
		}
		data = append(data, features)
	}
	forest.Train(data)

	// Normal point should have low anomaly score
	normal := []float64{0.2, 0.05, 0.05, 0.05, 0.25, 0.25, 0.2, 0.02, 0.3, 0.2}
	normalScore := forest.Predict(normal)
	if normalScore > 0.7 {
		t.Errorf("normal point score too high: %.3f", normalScore)
	}

	// Anomalous point should have high anomaly score
	anomaly := []float64{0.95, 1.0, 1.0, 1.0, 0.9, 0.85, 0.8, 0.7, 0.9, 0.8}
	anomalyScore := forest.Predict(anomaly)
	if anomalyScore < 0.5 {
		t.Errorf("anomaly point score too low: %.3f", anomalyScore)
	}

	// Anomaly score should be higher than normal score
	if anomalyScore <= normalScore {
		t.Errorf("anomaly (%.3f) should score higher than normal (%.3f)", anomalyScore, normalScore)
	}
}

func TestIsolationForest_EmptyData(t *testing.T) {
	forest := NewIsolationForest(10, 32)
	forest.Train(nil)

	score := forest.Predict([]float64{0.5, 0.5, 0.5})
	if score != 0.5 {
		t.Errorf("expected 0.5 for untrained model, got %.3f", score)
	}
}

func TestIsolationForest_ScoreRange(t *testing.T) {
	forest := NewIsolationForest(50, 128)

	var data [][]float64
	for i := 0; i < 200; i++ {
		features := make([]float64, 10)
		for j := range features {
			features[j] = float64(i%20) / 20.0
		}
		data = append(data, features)
	}
	forest.Train(data)

	// All scores should be in [0, 1]
	testPoints := [][]float64{
		{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
		{1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
		{0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5},
	}

	for _, point := range testPoints {
		score := forest.Predict(point)
		if score < 0 || score > 1 {
			t.Errorf("score %.3f out of range [0,1] for point %v", score, point)
		}
		if math.IsNaN(score) || math.IsInf(score, 0) {
			t.Errorf("score is NaN or Inf for point %v", point)
		}
	}
}

func TestBuildFeatures(t *testing.T) {
	profile := &Profile{
		ActiveStart:  9,
		ActiveEnd:    18,
		KnownIPs:     `["192.168.1.10"]`,
		FavoritePaths: `["/upload"]`,
		FavoriteExts:  `[".xlsx"]`,
		AvgUpload:    10.0,
		AvgDownload:  20.0,
	}

	events := []Event{
		{IP: "192.168.1.10", Action: "LOGIN", Path: "", Size: 0, Status: "success", Time: parseTime("2026-05-20 14:00:00")},
		{IP: "192.168.1.10", Action: "DOWNLOAD", Path: "/upload/test.xlsx", Size: 1024, Status: "", Time: parseTime("2026-05-20 14:01:00")},
	}

	features := BuildFeatures(profile, events)

	if len(features) != 10 {
		t.Fatalf("expected 10 features, got %d", len(features))
	}

	// Login hour deviation: |14 - 13.5| / 12 = 0.042 → small
	if features[0] > 0.1 {
		t.Errorf("login hour deviation too high: %.3f", features[0])
	}

	// is_new_ip: 192.168.1.10 is known → 0
	if features[1] != 0 {
		t.Errorf("is_new_ip should be 0, got %.1f", features[1])
	}

	// is_new_path: /upload is known → 0
	if features[2] != 0 {
		t.Errorf("is_new_path should be 0, got %.1f", features[2])
	}
}

func parseTime(s string) time.Time {
	t, _ := time.Parse("2006-01-02 15:04:05", s)
	return t
}
