package services

import (
	"encoding/json"
	"fmt"
	"log"
	"math/rand"
	"sync"
	"time"

	"ai-sftp-sentinel/models"

	"gorm.io/gorm"
)

// RiskScorer combines rule-based scoring with Isolation Forest + LLM explanation.
type RiskScorer struct {
	db     *gorm.DB
	forest *IsolationForest
	llm    *LLMClient
	mu     sync.RWMutex
}

func NewRiskScorer(db *gorm.DB, llmClient *LLMClient) *RiskScorer {
	return &RiskScorer{
		db:     db,
		forest: NewIsolationForest(100, 256),
		llm:    llmClient,
	}
}

// TrainForest trains the Isolation Forest model from historical profile data.
// Generates synthetic normal behavior samples based on existing profiles.
func (rs *RiskScorer) TrainForest() error {
	rs.mu.Lock()
	defer rs.mu.Unlock()

	var profiles []Profile
	rs.db.Find(&profiles)

	if len(profiles) == 0 {
		log.Println("[risk] no profiles found, generating synthetic training data")
		rs.forest.Train(rs.generateSyntheticData())
		return nil
	}

	// Generate normal behavior vectors from profiles
	var data [][]float64
	rng := rand.New(rand.NewSource(42))
	for _, p := range profiles {
		for i := 0; i < 50; i++ {
			features := []float64{
				rng.NormFloat64()*0.15 + 0.2, // login_hour_deviation (centered in work hours)
				rng.Float64() * 0.15,           // mostly known IPs
				rng.Float64() * 0.15,           // mostly known paths
				rng.Float64() * 0.15,           // mostly known exts
				rng.NormFloat64()*0.15 + 0.25,  // upload_deviation
				rng.NormFloat64()*0.15 + 0.25,  // download_deviation
				rng.NormFloat64()*0.15 + 0.25,  // transfer_deviation
				rng.Float64() * 0.1,            // few failures
				rng.NormFloat64()*0.15 + 0.3,   // session_duration
				rng.NormFloat64()*0.1 + 0.2,    // event_density
			}
			for j := range features {
				if features[j] < 0 {
					features[j] = 0
				}
				if features[j] > 1 {
					features[j] = 1
				}
			}
			data = append(data, features)
		}
	}

	// Add ~5% anomalous samples
	for i := 0; i < len(data)/19; i++ {
		features := []float64{
			0.7 + rng.Float64()*0.3, // off-hours
			0.7 + rng.Float64()*0.3, // new IP
			0.6 + rng.Float64()*0.4, // new path
			0.5 + rng.Float64()*0.5, // new ext
			0.7 + rng.Float64()*0.3, // high upload
			0.7 + rng.Float64()*0.3, // high download
			0.7 + rng.Float64()*0.3, // high transfer
			0.3 + rng.Float64()*0.7, // failures
			0.5 + rng.Float64()*0.5, // long session
			0.5 + rng.Float64()*0.5, // high density
		}
		data = append(data, features)
	}

	rs.forest.Train(data)
	log.Printf("[risk] Isolation Forest trained with %d samples (%d normal, ~%d anomalous)",
		len(data), len(data)-len(data)/19, len(data)/19)
	return nil
}

func (rs *RiskScorer) generateSyntheticData() [][]float64 {
	rng := rand.New(rand.NewSource(42))
	var data [][]float64
	for i := 0; i < 1000; i++ {
		features := []float64{
			rng.NormFloat64()*0.15 + 0.2,
			rng.Float64() * 0.15,
			rng.Float64() * 0.15,
			rng.Float64() * 0.15,
			rng.NormFloat64()*0.15 + 0.25,
			rng.NormFloat64()*0.15 + 0.25,
			rng.NormFloat64()*0.15 + 0.25,
			rng.Float64() * 0.1,
			rng.NormFloat64()*0.15 + 0.3,
			rng.NormFloat64()*0.1 + 0.2,
		}
		for j := range features {
			if features[j] < 0 {
				features[j] = 0
			}
			if features[j] > 1 {
				features[j] = 1
			}
		}
		data = append(data, features)
	}
	return data
}

// EnrichAlert enriches a single alert with AI score and LLM explanation.
func (rs *RiskScorer) EnrichAlert(alert *models.Alert) error {
	rs.mu.RLock()
	defer rs.mu.RUnlock()

	// Get profile
	var profile Profile
	rs.db.Where("user = ?", alert.User).First(&profile)

	// Get session events
	var events []Event
	rs.db.Where("session_id = ?", alert.SessionID).Order("time ASC").Find(&events)

	if len(events) == 0 {
		return nil
	}

	// Build features and predict anomaly
	features := BuildFeatures(&profile, events)
	aiScore := rs.forest.Predict(features)

	aiScoreInt := int(aiScore * 100)
	if aiScoreInt > 100 {
		aiScoreInt = 100
	}

	alert.AIScore = aiScoreInt
	alert.Score = (alert.RuleScore + aiScoreInt) / 2
	alert.Level = models.ScoreToLevel(alert.Score)

	// Get LLM explanation
	riskLevel, explanation, suggestions := rs.llm.Explain(
		alert.User, &profile, events, features, alert.RuleScore)

	if riskLevel != "" && riskLevel != alert.Level {
		alert.AIExplain = fmt.Sprintf("[%s] %s", riskLevel, explanation)
	} else {
		alert.AIExplain = explanation
	}

	if len(suggestions) > 0 {
		alert.AIExplain += "\n建议：" + joinStrings(suggestions, "；")
	}

	return nil
}

// EnrichAllPending enriches all alerts without AI scores.
func (rs *RiskScorer) EnrichAllPending() (int, error) {
	var alerts []models.Alert
	rs.db.Where("ai_score = 0").Find(&alerts)

	count := 0
	for i := range alerts {
		if err := rs.EnrichAlert(&alerts[i]); err != nil {
			log.Printf("[risk] enrichment failed for alert %d: %v", alerts[i].ID, err)
			continue
		}
		if err := rs.db.Save(&alerts[i]).Error; err != nil {
			return count, err
		}
		count++
	}
	return count, nil
}

// GetForestStats returns model statistics.
func (rs *RiskScorer) GetForestStats() map[string]interface{} {
	rs.mu.RLock()
	defer rs.mu.RUnlock()
	return map[string]interface{}{
		"num_trees":     rs.forest.NumTrees,
		"sample_size":   rs.forest.SampleSize,
		"num_features":  rs.forest.NumFeatures,
		"training_size": len(rs.forest.TrainingData),
		"feature_names": FeatureNames(),
	}
}

// JSON helpers
type Profile = models.Profile
type Event = models.Event

func joinStrings(ss []string, sep string) string {
	result := ""
	for i, s := range ss {
		if i > 0 {
			result += sep
		}
		result += s
	}
	return result
}
