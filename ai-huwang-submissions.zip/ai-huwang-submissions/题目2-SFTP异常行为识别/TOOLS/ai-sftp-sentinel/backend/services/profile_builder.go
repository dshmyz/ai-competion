package services

import (
	"encoding/json"
	"fmt"
	"math"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/models"

	"gorm.io/gorm"
)

type ProfileBuilder struct {
	db  *gorm.DB
	cfg *config.Config
}

func NewProfileBuilder(db *gorm.DB, cfg *config.Config) *ProfileBuilder {
	return &ProfileBuilder{db: db, cfg: cfg}
}

// BuildAllProfiles rebuilds all user profiles from historical events.
func (pb *ProfileBuilder) BuildAllProfiles() (int, error) {
	var users []string
	pb.db.Model(&models.Event{}).Distinct().Pluck("user", &users)

	count := 0
	for _, user := range users {
		if user == "" {
			continue
		}
		if err := pb.buildProfile(user); err != nil {
			fmt.Printf("[profile] error building profile for %s: %v\n", user, err)
			continue
		}
		count++
	}

	return count, nil
}

func (pb *ProfileBuilder) buildProfile(user string) error {
	cutoff := time.Now().AddDate(0, 0, -pb.cfg.ProfileDays)

	var events []models.Event
	pb.db.Where("user = ? AND time >= ? AND action != ''", user, cutoff).
		Order("time ASC").
		Find(&events)

	if len(events) == 0 {
		return nil
	}

	profile := models.Profile{
		User:      user,
		UpdatedAt: time.Now(),
	}

	// Time profile
	hourCounts := make(map[int]int)
	for _, ev := range events {
		hourCounts[ev.Time.Hour()]++
	}
	profile.ActiveStart, profile.ActiveEnd = computeActiveHours(hourCounts)

	// IP profile
	ipCounts := make(map[string]int)
	for _, ev := range events {
		if ev.IP != "" {
			ipCounts[ev.IP]++
		}
	}
	knownIPs := topN(ipCounts, 10)
	ipsJSON, _ := json.Marshal(knownIPs)
	profile.KnownIPs = string(ipsJSON)

	// Path profile
	pathCounts := make(map[string]int)
	for _, ev := range events {
		if ev.Path != "" {
			dir := filepath.Dir(ev.Path)
			pathCounts[dir]++
		}
	}
	favPaths := topN(pathCounts, 10)
	pathsJSON, _ := json.Marshal(favPaths)
	profile.FavoritePaths = string(pathsJSON)

	// File extension profile
	extCounts := make(map[string]int)
	for _, ev := range events {
		if ev.Path != "" {
			ext := filepath.Ext(ev.Path)
			if ext != "" {
				extCounts[strings.ToLower(ext)]++
			}
		}
	}
	favExts := topN(extCounts, 10)
	extsJSON, _ := json.Marshal(favExts)
	profile.FavoriteExts = string(extsJSON)

	// Transfer profile
	var totalUpload, totalDownload int64
	uploadDays := make(map[string]int64)
	downloadDays := make(map[string]int64)
	for _, ev := range events {
		day := ev.Time.Format("2006-01-02")
		switch ev.Action {
		case "UPLOAD":
			totalUpload += ev.Size
			uploadDays[day] += ev.Size
		case "DOWNLOAD":
			totalDownload += ev.Size
			downloadDays[day] += ev.Size
		}
	}

	days := uniqueDays(events)
	if days == 0 {
		days = 1
	}
	profile.DaysTracked = days
	profile.AvgUpload = float64(totalUpload) / float64(days) / 1024 / 1024
	profile.AvgDownload = float64(totalDownload) / float64(days) / 1024 / 1024
	profile.AvgTransfer = profile.AvgUpload + profile.AvgDownload

	// Login stats
	loginCount := 0
	for _, ev := range events {
		if ev.Action == "LOGIN" && ev.Status == "success" {
			loginCount++
		}
	}
	profile.LoginCount = loginCount

	// Session count
	var sessionCount int64
	pb.db.Model(&models.Session{}).Where("user = ?", user).Count(&sessionCount)
	profile.SessionCount = int(sessionCount)

	// Upsert
	var existing models.Profile
	result := pb.db.Where("user = ?", user).First(&existing)
	if result.Error == gorm.ErrRecordNotFound {
		return pb.db.Create(&profile).Error
	}
	profile.ID = existing.ID
	return pb.db.Save(&profile).Error
}

func computeActiveHours(hourCounts map[int]int) (int, int) {
	if len(hourCounts) == 0 {
		return 9, 18
	}

	type kv struct {
		Hour  int
		Count int
	}
	var sorted []kv
	for h, c := range hourCounts {
		sorted = append(sorted, kv{h, c})
	}
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].Count > sorted[j].Count })

	// Find the most common hour, then expand to contiguous range covering 80% of activity
	total := 0
	for _, s := range sorted {
		total += s.Count
	}

	// Use top hours until covering 80% of events
	threshold := float64(total) * 0.8
	accum := 0
	var activeHours []int
	for _, s := range sorted {
		activeHours = append(activeHours, s.Hour)
		accum += s.Count
		if float64(accum) >= threshold {
			break
		}
	}
	sort.Ints(activeHours)

	if len(activeHours) == 0 {
		return 9, 18
	}
	return activeHours[0], activeHours[len(activeHours)-1]
}

func topN(counts map[string]int, n int) []string {
	type kv struct {
		Key   string
		Count int
	}
	var sorted []kv
	for k, c := range counts {
		sorted = append(sorted, kv{k, c})
	}
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].Count > sorted[j].Count })

	result := make([]string, 0, int(math.Min(float64(n), float64(len(sorted)))))
	for i := 0; i < len(sorted) && i < n; i++ {
		result = append(result, sorted[i].Key)
	}
	return result
}

func uniqueDays(events []models.Event) int {
	days := make(map[string]bool)
	for _, ev := range events {
		days[ev.Time.Format("2006-01-02")] = true
	}
	return len(days)
}
