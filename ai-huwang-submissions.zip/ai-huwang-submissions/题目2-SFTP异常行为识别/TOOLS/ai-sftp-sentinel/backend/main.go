package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/db"
	"ai-sftp-sentinel/logcollector"
	"ai-sftp-sentinel/router"
	"ai-sftp-sentinel/services"
)

func main() {
	cfg := config.Load()

	// Init database
	database, err := db.Init(cfg)
	if err != nil {
		log.Fatalf("Failed to initialize database: %v", err)
	}

	// Init LLM client (Go-native, no Python)
	llmClient := services.NewLLMClient(cfg.OllamaURL, cfg.OllamaModel)

	// Init risk scorer with Go-native Isolation Forest
	scorer := services.NewRiskScorer(database, llmClient)

	// Train Isolation Forest
	if err := scorer.TrainForest(); err != nil {
		log.Printf("[warning] Forest training failed: %v", err)
	}

	// Start log tail collector if log files configured
	if len(cfg.LogFiles) > 0 {
		tail := logcollector.NewTailCollector(database, cfg.LogFiles, time.Duration(cfg.TailInterval)*time.Second)
		tail.Start()
		defer tail.Stop()
	}

	// Setup router
	r := router.Setup(database, cfg, scorer)

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)

	addr := fmt.Sprintf(":%s", cfg.Port)
	log.Printf("AI-SFTP Sentinel starting on %s", addr)
	log.Printf("  Log files: %v", cfg.LogFiles)
	log.Printf("  Ollama: %s (model: %s)", cfg.OllamaURL, cfg.OllamaModel)
	log.Printf("  DB: %s", cfg.DBPath)

	go func() {
		if err := r.Run(addr); err != nil {
			log.Fatalf("Failed to start server: %v", err)
		}
	}()

	<-quit
	log.Println("Shutting down AI-SFTP Sentinel...")
}
