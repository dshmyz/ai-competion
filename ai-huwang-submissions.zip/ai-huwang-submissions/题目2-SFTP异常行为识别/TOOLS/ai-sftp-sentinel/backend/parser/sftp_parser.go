package parser

import (
	"regexp"
	"strconv"
	"strings"
	"time"

	"ai-sftp-sentinel/models"
)

// Supported log formats:
// 1. OpenSSH auth.log style:
//    May 20 09:13:21 host sshd[12345]: Accepted password for alice from 192.168.1.10 port 22 ssh2
//    May 20 09:13:22 host internal-sftp[12345]: session opened for local user alice from [192.168.1.10]
//    May 20 09:13:30 host internal-sftp[12345]: close "/upload/file.txt" bytes read 1024 written 0
// 2. Structured key=value format:
//    2026-05-20 09:13:21 user=alice ip=192.168.1.10 action=login status=success
// 3. auditd style

var (
	// OpenSSH sftp-server / internal-sftp patterns
	reSFTPOpen  = regexp.MustCompile(`(\w+ \d+ \d+:\d+:\d+)\s+(\S+)\s+(?:internal-sftp|sftp-server)\[(\d+)\].*session opened for local user (\S+) from \[?([^\]\s]+)\]?`)
	reSFTPClose = regexp.MustCompile(`(\w+ \d+ \d+:\d+:\d+)\s+(\S+)\s+(?:internal-sftp|sftp-server)\[(\d+)\].*session closed for local user (\S+)`)
	reSFTPOp    = regexp.MustCompile(`(\w+ \d+ \d+:\d+:\d+)\s+(\S+)\s+(?:internal-sftp|sftp-server)\[(\d+)\].*\b(open|close|read|write|remove|rename|mkdir|rmdir|stat|lstat|fstat|readdir|realpath)\b "([^"]*)"(?:.*bytes read (\d+))?(?:.*bytes written (\d+))?`)

	// SSH login patterns
	reSSHAccept = regexp.MustCompile(`(\w+ \d+ \d+:\d+:\d+)\s+(\S+)\s+sshd\[(\d+)\]: Accepted \S+ for (\S+) from ([\d.]+) port \d+`)
	reSSHFail   = regexp.MustCompile(`(\w+ \d+ \d+:\d+:\d+)\s+(\S+)\s+sshd\[(\d+)\]: Failed \S+ for (?:invalid user )?(\S+) from ([\d.]+) port \d+`)

	// Key=value format
	reKV = regexp.MustCompile(`(\w+)=([^ ]+)`)
)

// ParseLine attempts to parse a single log line into zero or more Events.
func ParseLine(line, sourceFile string, year int) []models.Event {
	var events []models.Event

	if ev := parseKVLine(line, sourceFile, year); ev != nil {
		events = append(events, *ev)
		return events
	}

	if evs := parseSSHLogLine(line, sourceFile, year); len(evs) > 0 {
		return evs
	}

	return events
}

func parseKVLine(line, sourceFile string, year int) *models.Event {
	kv := make(map[string]string)
	for _, m := range reKV.FindAllStringSubmatch(line, -1) {
		kv[m[1]] = m[2]
	}

	timeStr, ok := kv["time"]
	if !ok {
		return nil
	}
	user, ok := kv["user"]
	if !ok {
		return nil
	}
	ip := kv["ip"]
	action := kv["action"]

	t, err := time.Parse("2006-01-02 15:04:05", timeStr)
	if err != nil {
		return nil
	}

	path := kv["file"]
	if path == "" {
		path = kv["path"]
	}

	size, _ := strconv.ParseInt(kv["size"], 10, 64)

	return &models.Event{
		User:       user,
		IP:         ip,
		Action:     normalizeAction(action),
		Path:       path,
		Size:       size,
		Time:       t,
		Status:     kv["status"],
		SourceFile: sourceFile,
		Raw:        line,
	}
}

func parseSSHLogLine(line, sourceFile string, year int) []models.Event {
	var events []models.Event

	// SSH login accepted
	if m := reSSHAccept.FindStringSubmatch(line); m != nil {
		t := parseSyslogTime(m[1], year)
		events = append(events, models.Event{
			User:       m[4],
			IP:         m[5],
			Action:     "LOGIN",
			Status:     "success",
			Time:       t,
			SourceFile: sourceFile,
			Raw:        line,
		})
		return events
	}

	// SSH login failed
	if m := reSSHFail.FindStringSubmatch(line); m != nil {
		t := parseSyslogTime(m[1], year)
		events = append(events, models.Event{
			User:       m[4],
			IP:         m[5],
			Action:     "LOGIN",
			Status:     "failed",
			Time:       t,
			SourceFile: sourceFile,
			Raw:        line,
		})
		return events
	}

	// SFTP session opened
	if m := reSFTPOpen.FindStringSubmatch(line); m != nil {
		t := parseSyslogTime(m[1], year)
		events = append(events, models.Event{
			User:       m[4],
			IP:         m[5],
			Action:     "LOGIN",
			Status:     "success",
			Time:       t,
			SourceFile: sourceFile,
			Raw:        line,
		})
		return events
	}

	// SFTP session closed
	if m := reSFTPClose.FindStringSubmatch(line); m != nil {
		t := parseSyslogTime(m[1], year)
		events = append(events, models.Event{
			User:       m[4],
			Action:     "LOGOUT",
			Time:       t,
			SourceFile: sourceFile,
			Raw:        line,
		})
		return events
	}

	// SFTP file operations
	if m := reSFTPOp.FindStringSubmatch(line); m != nil {
		t := parseSyslogTime(m[1], year)
		op := m[4]
		path := m[5]
		readBytes, _ := strconv.ParseInt(m[6], 10, 64)
		writeBytes, _ := strconv.ParseInt(m[7], 10, 64)

		action := normalizeSFTPOp(op)
		size := readBytes + writeBytes

		// Infer action from size when possible
		if action == "UNKNOWN" {
			if writeBytes > 0 {
				action = "UPLOAD"
			} else if readBytes > 0 {
				action = "DOWNLOAD"
			}
		}

		events = append(events, models.Event{
			Path:       path,
			Action:     action,
			Size:       size,
			Time:       t,
			SourceFile: sourceFile,
			Raw:        line,
		})
	}

	return events
}

func parseSyslogTime(s string, year int) time.Time {
	// "May 20 09:13:21"
	t, err := time.Parse("Jan 2 15:04:05", s)
	if err != nil {
		return time.Time{}
	}
	return t.AddDate(year, 0, 0)
}

func normalizeAction(action string) string {
	switch strings.ToLower(action) {
	case "login":
		return "LOGIN"
	case "logout":
		return "LOGOUT"
	case "upload":
		return "UPLOAD"
	case "download":
		return "DOWNLOAD"
	case "delete":
		return "DELETE"
	case "mkdir":
		return "MKDIR"
	case "rmdir":
		return "RMDIR"
	case "rename":
		return "RENAME"
	case "read":
		return "DOWNLOAD"
	case "write":
		return "UPLOAD"
	default:
		return strings.ToUpper(action)
	}
}

func normalizeSFTPOp(op string) string {
	switch strings.ToLower(op) {
	case "open", "read", "readdir", "realpath", "stat", "lstat", "fstat":
		return "DOWNLOAD"
	case "write":
		return "UPLOAD"
	case "remove":
		return "DELETE"
	case "rename":
		return "RENAME"
	case "mkdir":
		return "MKDIR"
	case "rmdir":
		return "RMDIR"
	default:
		return "UNKNOWN"
	}
}
