package parser

import (
	"testing"
)

func TestParseKVLine(t *testing.T) {
	tests := []struct {
		name   string
		line   string
		user   string
		action string
		ip     string
		path   string
		size   int64
		status string
	}{
		{
			name:   "login success",
			line:   "2026-05-20 09:13:21 user=alice ip=192.168.1.10 action=login status=success",
			user:   "alice",
			action: "LOGIN",
			ip:     "192.168.1.10",
			status: "success",
		},
		{
			name:   "download with file",
			line:   "2026-05-20 09:15:03 user=bob ip=10.0.0.1 action=download file=/home/bob/report.docx size=204800",
			user:   "bob",
			action: "DOWNLOAD",
			ip:     "10.0.0.1",
			path:   "/home/bob/report.docx",
			size:   204800,
		},
		{
			name:   "login failed",
			line:   "2026-05-20 11:01:01 user=admin ip=103.21.45.9 action=login status=failed",
			user:   "admin",
			action: "LOGIN",
			ip:     "103.21.45.9",
			status: "failed",
		},
		{
			name: "empty line",
			line: "",
		},
		{
			name: "non-log line",
			line: "this is not a log line",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			events := ParseLine(tt.line, "test.log", 2026)
			if tt.user == "" {
				if len(events) != 0 {
					t.Errorf("expected 0 events, got %d", len(events))
				}
				return
			}
			if len(events) == 0 {
				t.Fatal("expected at least 1 event, got 0")
			}
			ev := events[0]
			if ev.User != tt.user {
				t.Errorf("user: got %s, want %s", ev.User, tt.user)
			}
			if ev.Action != tt.action {
				t.Errorf("action: got %s, want %s", ev.Action, tt.action)
			}
			if ev.IP != tt.ip {
				t.Errorf("ip: got %s, want %s", ev.IP, tt.ip)
			}
			if tt.path != "" && ev.Path != tt.path {
				t.Errorf("path: got %s, want %s", ev.Path, tt.path)
			}
			if tt.size > 0 && ev.Size != tt.size {
				t.Errorf("size: got %d, want %d", ev.Size, tt.size)
			}
		})
	}
}

func TestParseSSHLogLine(t *testing.T) {
	tests := []struct {
		name   string
		line   string
		user   string
		action string
		ip     string
	}{
		{
			name:   "ssh accepted",
			line:   "May 20 09:13:21 host sshd[12345]: Accepted password for alice from 192.168.1.10 port 22 ssh2",
			user:   "alice",
			action: "LOGIN",
			ip:     "192.168.1.10",
		},
		{
			name:   "ssh failed",
			line:   "May 20 11:01:01 host sshd[12346]: Failed password for admin from 103.21.45.9 port 1234",
			user:   "admin",
			action: "LOGIN",
			ip:     "103.21.45.9",
		},
		{
			name:   "invalid user",
			line:   "May 20 11:02:00 host sshd[12347]: Failed password for invalid user root from 10.0.0.1 port 5678",
			user:   "root",
			action: "LOGIN",
			ip:     "10.0.0.1",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			events := ParseLine(tt.line, "auth.log", 2026)
			if len(events) == 0 {
				t.Fatal("expected at least 1 event, got 0")
			}
			ev := events[0]
			if ev.User != tt.user {
				t.Errorf("user: got %s, want %s", ev.User, tt.user)
			}
			if ev.Action != tt.action {
				t.Errorf("action: got %s, want %s", ev.Action, tt.action)
			}
			if ev.IP != tt.ip {
				t.Errorf("ip: got %s, want %s", ev.IP, tt.ip)
			}
		})
	}
}

func TestParseSFTPOps(t *testing.T) {
	line := `May 20 09:15:00 host internal-sftp[12345]: open "/upload/report.xlsx" bytes read 102400 written 0`
	events := ParseLine(line, "sftp.log", 2026)
	if len(events) == 0 {
		t.Fatal("expected at least 1 event, got 0")
	}
	ev := events[0]
	if ev.Path != "/upload/report.xlsx" {
		t.Errorf("path: got %s, want /upload/report.xlsx", ev.Path)
	}
	if ev.Action != "DOWNLOAD" {
		t.Errorf("action: got %s, want DOWNLOAD", ev.Action)
	}
}
