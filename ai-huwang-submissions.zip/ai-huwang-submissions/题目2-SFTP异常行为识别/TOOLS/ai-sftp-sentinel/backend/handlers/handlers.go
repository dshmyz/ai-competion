package handlers

import (
	"net/http"
	"strconv"
	"time"

	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/logcollector"
	"ai-sftp-sentinel/models"
	"ai-sftp-sentinel/services"
	"ai-sftp-sentinel/sessionbuilder"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type Handler struct {
	db       *gorm.DB
	cfg      *config.Config
	collector *logcollector.TailCollector
	builder  *sessionbuilder.Builder
	profiler *services.ProfileBuilder
	detector *services.Detector
	scorer   *services.RiskScorer
}

func New(db *gorm.DB, cfg *config.Config, scorer *services.RiskScorer) *Handler {
	return &Handler{
		db:       db,
		cfg:      cfg,
		collector: logcollector.NewTailCollector(db, nil, 30*time.Second),
		builder:  sessionbuilder.New(db),
		profiler: services.NewProfileBuilder(db, cfg),
		detector: services.NewDetector(db, cfg),
		scorer:   scorer,
	}
}

// GET /api/dashboard
func (h *Handler) GetDashboard(c *gin.Context) {
	var stats models.DashboardStats
	h.db.Model(&models.Event{}).Distinct("user").Count(&stats.TotalUsers)
	h.db.Model(&models.Session{}).Count(&stats.TotalSessions)
	h.db.Model(&models.Event{}).Count(&stats.TotalEvents)
	h.db.Model(&models.Alert{}).Count(&stats.AlertCount)
	h.db.Model(&models.Alert{}).Where("level IN ('high', 'critical')").Count(&stats.HighAlertCount)
	today := time.Now().Format("2006-01-02")
	h.db.Model(&models.Event{}).Where("time >= ?", today).Count(&stats.TodayEvents)
	c.JSON(http.StatusOK, gin.H{"data": stats})
}

// GET /api/alerts
func (h *Handler) GetAlerts(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "20"))
	level := c.Query("level")
	user := c.Query("user")

	query := h.db.Model(&models.Alert{})
	if level != "" {
		query = query.Where("level = ?", level)
	}
	if user != "" {
		query = query.Where("user = ?", user)
	}

	var total int64
	query.Count(&total)

	var alerts []models.Alert
	query.Order("score DESC, time DESC").Offset((page - 1) * size).Limit(size).Find(&alerts)

	c.JSON(http.StatusOK, gin.H{"data": alerts, "total": total, "page": page, "size": size})
}

// GET /api/alerts/top
func (h *Handler) GetTopAlerts(c *gin.Context) {
	var alerts []models.Alert
	h.db.Order("score DESC").Limit(10).Find(&alerts)
	c.JSON(http.StatusOK, gin.H{"data": alerts})
}

// GET /api/users
func (h *Handler) GetUsers(c *gin.Context) {
	var profiles []models.Profile
	h.db.Order("user ASC").Find(&profiles)
	c.JSON(http.StatusOK, gin.H{"data": profiles})
}

// GET /api/users/:user/profile
func (h *Handler) GetUserProfile(c *gin.Context) {
	user := c.Param("user")
	var profile models.Profile
	if err := h.db.Where("user = ?", user).First(&profile).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "profile not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": profile})
}

// GET /api/users/:user/events
func (h *Handler) GetUserEvents(c *gin.Context) {
	user := c.Param("user")
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "50"))

	var total int64
	h.db.Model(&models.Event{}).Where("user = ?", user).Count(&total)

	var events []models.Event
	h.db.Where("user = ?", user).Order("time DESC").Offset((page - 1) * size).Limit(size).Find(&events)

	c.JSON(http.StatusOK, gin.H{"data": events, "total": total, "page": page, "size": size})
}

// GET /api/events
func (h *Handler) GetEvents(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "50"))
	action := c.Query("action")
	user := c.Query("user")

	query := h.db.Model(&models.Event{})
	if action != "" {
		query = query.Where("action = ?", action)
	}
	if user != "" {
		query = query.Where("user = ?", user)
	}

	var total int64
	query.Count(&total)

	var events []models.Event
	query.Order("time DESC").Offset((page - 1) * size).Limit(size).Find(&events)

	c.JSON(http.StatusOK, gin.H{"data": events, "total": total, "page": page, "size": size})
}

// GET /api/sessions
func (h *Handler) GetSessions(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "20"))

	var total int64
	h.db.Model(&models.Session{}).Count(&total)

	var sessions []models.Session
	h.db.Order("login_time DESC").Offset((page - 1) * size).Limit(size).Find(&sessions)

	c.JSON(http.StatusOK, gin.H{"data": sessions, "total": total, "page": page, "size": size})
}

// POST /api/import
func (h *Handler) ImportLog(c *gin.Context) {
	var req struct {
		Path string `json:"path" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	count, err := h.collector.ImportFile(req.Path)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"imported": count})
}

// POST /api/collect
func (h *Handler) TriggerCollect(c *gin.Context) {
	var req struct {
		Files []string `json:"files" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "files is required"})
		return
	}

	tc := logcollector.NewTailCollector(h.db, req.Files, 30*time.Second)
	total := 0
	for _, f := range req.Files {
		count, err := tc.ImportFile(f)
		if err != nil {
			continue
		}
		total += count
	}

	c.JSON(http.StatusOK, gin.H{"collected": total})
}

// POST /api/sessions/build
func (h *Handler) BuildSessions(c *gin.Context) {
	count, err := h.builder.BuildSessions()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"sessions": count})
}

// POST /api/profiles/build
func (h *Handler) BuildProfiles(c *gin.Context) {
	count, err := h.profiler.BuildAllProfiles()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"profiles": count})
}

// POST /api/detect
func (h *Handler) RunDetection(c *gin.Context) {
	count, err := h.detector.DetectLatest()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"alerts": count})
}

// POST /api/forest/train
func (h *Handler) TrainForest(c *gin.Context) {
	if err := h.scorer.TrainForest(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	stats := h.scorer.GetForestStats()
	c.JSON(http.StatusOK, gin.H{"status": "ok", "model": stats})
}

// GET /api/ai/stats
func (h *Handler) GetAIStats(c *gin.Context) {
	stats := h.scorer.GetForestStats()
	c.JSON(http.StatusOK, gin.H{"data": stats})
}

// POST /api/analyze/run-all
func (h *Handler) RunFullAnalysis(c *gin.Context) {
	// 1. Build sessions
	sessCount, err := h.builder.BuildSessions()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "session build: " + err.Error()})
		return
	}

	// 2. Build profiles
	profileCount, err := h.profiler.BuildAllProfiles()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "profile build: " + err.Error()})
		return
	}

	// 3. Retrain forest with new profiles
	if err := h.scorer.TrainForest(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "forest train: " + err.Error()})
		return
	}

	// 4. Run detection
	alertCount, err := h.detector.DetectLatest()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "detection: " + err.Error()})
		return
	}

	// 5. AI enrichment
	aiCount, _ := h.scorer.EnrichAllPending()

	c.JSON(http.StatusOK, gin.H{
		"sessions":       sessCount,
		"profiles":       profileCount,
		"alerts":         alertCount,
		"ai_enrichments": aiCount,
	})
}
