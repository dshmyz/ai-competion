package config

import (
	"os"
	"strings"
)

type Config struct {
	Port         string
	DBPath       string
	LogFiles     []string // files to watch
	TailInterval int      // seconds between tail scans
	OllamaURL    string
	OllamaModel  string
	ProfileDays  int
	Threshold    struct {
		OffHourStart     int
		OffHourEnd       int
		DownloadMultiple float64
		UploadMultiple   float64
		NewIPScore       int
		NewDirScore      int
		NewExtScore      int
		OffHourScore     int
	}
}

func Load() *Config {
	cfg := &Config{
		Port:         getEnv("PORT", "8080"),
		DBPath:       getEnv("DB_PATH", "sentinel.db"),
		TailInterval: 30,
		OllamaURL:    getEnv("OLLAMA_URL", "http://localhost:11434"),
		OllamaModel:  getEnv("OLLAMA_MODEL", "qwen3:8b"),
		ProfileDays:  30,
	}

	// Log files from env (comma-separated)
	logFiles := getEnv("LOG_FILES", "")
	if logFiles != "" {
		cfg.LogFiles = strings.Split(logFiles, ",")
	}

	cfg.Threshold.OffHourStart = 0
	cfg.Threshold.OffHourEnd = 6
	cfg.Threshold.DownloadMultiple = 5.0
	cfg.Threshold.UploadMultiple = 5.0
	cfg.Threshold.NewIPScore = 25
	cfg.Threshold.NewDirScore = 15
	cfg.Threshold.NewExtScore = 10
	cfg.Threshold.OffHourScore = 20

	return cfg
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
