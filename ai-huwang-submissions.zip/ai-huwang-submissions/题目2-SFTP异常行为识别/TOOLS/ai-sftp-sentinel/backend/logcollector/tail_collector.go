package logcollector

import (
	"bufio"
	"encoding/json"
	"io"
	"log"
	"os"
	"sync"
	"time"

	"ai-sftp-sentinel/models"
	"ai-sftp-sentinel/parser"

	"gorm.io/gorm"
)

// TailCollector watches log files for new content and imports events in real-time.
type TailCollector struct {
	db       *gorm.DB
	files    []string
	interval time.Duration
	offsets  map[string]int64
	mu       sync.Mutex
	stopCh   chan struct{}
}

func NewTailCollector(db *gorm.DB, files []string, interval time.Duration) *TailCollector {
	return &TailCollector{
		db:       db,
		files:    files,
		interval: interval,
		offsets:  make(map[string]int64),
		stopCh:   make(chan struct{}),
	}
}

// Start begins tailing log files in a background goroutine.
func (tc *TailCollector) Start() {
	go tc.loop()
	log.Printf("[tail] started watching %d files every %s", len(tc.files), tc.interval)
}

// Stop terminates the tail loop.
func (tc *TailCollector) Stop() {
	close(tc.stopCh)
}

func (tc *TailCollector) loop() {
	// Process existing content first
	tc.scanAll()

	ticker := time.NewTicker(tc.interval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			tc.scanAll()
		case <-tc.stopCh:
			return
		}
	}
}

func (tc *TailCollector) scanAll() {
	year := time.Now().Year()
	for _, path := range tc.files {
		count, err := tc.scanFile(path, year)
		if err != nil {
			log.Printf("[tail] error scanning %s: %v", path, err)
		}
		if count > 0 {
			log.Printf("[tail] imported %d new events from %s", count, path)
		}
	}
}

func (tc *TailCollector) scanFile(path string, year int) (int, error) {
	tc.mu.Lock()
	offset := tc.offsets[path]
	tc.mu.Unlock()

	f, err := os.Open(path)
	if err != nil {
		return 0, err
	}
	defer f.Close()

	// Check file size
	info, err := f.Stat()
	if err != nil {
		return 0, err
	}

	// If file was truncated (rotated), reset offset
	if info.Size() < offset {
		offset = 0
	}

	if _, err := f.Seek(offset, io.SeekStart); err != nil {
		return 0, err
	}

	count := 0
	var batch []models.Event
	scanner := bufio.NewScanner(f)

	for scanner.Scan() {
		line := scanner.Text()
		events := parser.ParseLine(line, path, year)
		for _, ev := range events {
			if ev.User != "" {
				batch = append(batch, ev)
				count++
			}
		}
	}

	// Update offset
	newOffset, _ := f.Seek(0, io.SeekCurrent)
	tc.mu.Lock()
	tc.offsets[path] = newOffset
	tc.mu.Unlock()

	// Batch insert
	if len(batch) > 0 {
		tc.db.CreateInBatches(batch, 500)
	}

	return count, scanner.Err()
}

// ImportFile imports a specific file in full (non-tail mode).
func (tc *TailCollector) ImportFile(path string) (int, error) {
	year := time.Now().Year()
	f, err := os.Open(path)
	if err != nil {
		return 0, err
	}
	defer f.Close()

	count := 0
	var batch []models.Event
	scanner := bufio.NewScanner(f)

	for scanner.Scan() {
		line := scanner.Text()
		events := parser.ParseLine(line, path, year)
		for _, ev := range events {
			if ev.User != "" {
				batch = append(batch, ev)
				count++
			}
		}
		if len(batch) >= 500 {
			tc.db.CreateInBatches(batch, 500)
			batch = batch[:0]
		}
	}
	if len(batch) > 0 {
		tc.db.CreateInBatches(batch, len(batch))
	}

	return count, scanner.Err()
}

// GetState returns current file offsets (for debugging).
func (tc *TailCollector) GetState() map[string]int64 {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	result := make(map[string]int64)
	for k, v := range tc.offsets {
		result[k] = v
	}
	return result
}

// StateJSON returns state as JSON string.
func (tc *TailCollector) StateJSON() string {
	state := tc.GetState()
	data, _ := json.MarshalIndent(state, "", "  ")
	return string(data)
}
