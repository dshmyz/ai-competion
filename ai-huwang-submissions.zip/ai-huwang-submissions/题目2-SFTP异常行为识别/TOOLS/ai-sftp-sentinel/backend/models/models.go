package models

import "time"

// Event represents a single SFTP log event.
type Event struct {
	ID          uint      `json:"id" gorm:"primaryKey"`
	User        string    `json:"user" gorm:"index"`
	SessionID   string    `json:"session_id" gorm:"index"`
	IP          string    `json:"ip"`
	Action      string    `json:"action"` // LOGIN, UPLOAD, DOWNLOAD, DELETE, MKDIR, RMDIR, LOGOUT
	Path        string    `json:"path"`
	Size        int64     `json:"size"`
	Time        time.Time `json:"time" gorm:"index"`
	Status      string    `json:"status"` // success, failed
	SourceFile  string    `json:"source_file"`
	Raw         string    `json:"raw"`
}

// Session represents a reconstructed SFTP session.
type Session struct {
	ID        string    `json:"id" gorm:"primaryKey"`
	User      string    `json:"user" gorm:"index"`
	IP        string    `json:"ip"`
	LoginTime time.Time `json:"login_time"`
	LogoutTime *time.Time `json:"logout_time"`
	EventCount int      `json:"event_count"`
	TotalUpload int64   `json:"total_upload"`
	TotalDownload int64 `json:"total_download"`
}

// Profile represents a user behavior profile.
type Profile struct {
	ID            uint      `json:"id" gorm:"primaryKey"`
	User          string    `json:"user" gorm:"uniqueIndex"`
	ActiveStart   int       `json:"active_start"` // hour 0-23
	ActiveEnd     int       `json:"active_end"`
	KnownIPs      string    `json:"known_ips"`      // JSON array
	FavoritePaths string    `json:"favorite_paths"` // JSON array
	FavoriteExts  string    `json:"favorite_exts"`  // JSON array
	AvgUpload     float64   `json:"avg_upload"`     // MB/day
	AvgDownload   float64   `json:"avg_download"`   // MB/day
	AvgTransfer   float64   `json:"avg_transfer"`   // MB/day
	LoginCount    int       `json:"login_count"`
	SessionCount  int       `json:"session_count"`
	DaysTracked   int       `json:"days_tracked"`
	UpdatedAt     time.Time `json:"updated_at"`
}

// Alert represents an anomaly detection result.
type Alert struct {
	ID          uint      `json:"id" gorm:"primaryKey"`
	User        string    `json:"user" gorm:"index"`
	SessionID   string    `json:"session_id"`
	IP          string    `json:"ip"`
	Score       int       `json:"score"`
	Level       string    `json:"level"` // low, medium, high, critical
	RuleScore   int       `json:"rule_score"`
	AIScore     int       `json:"ai_score"`
	Reasons     string    `json:"reasons"` // JSON array
	AIExplain   string    `json:"ai_explain"`
	Time        time.Time `json:"time" gorm:"index"`
	CreatedAt   time.Time `json:"created_at"`
}

// DashboardStats holds aggregate statistics.
type DashboardStats struct {
	TotalUsers     int64 `json:"total_users"`
	TotalSessions  int64 `json:"total_sessions"`
	TotalEvents    int64 `json:"total_events"`
	AlertCount     int64 `json:"alert_count"`
	HighAlertCount int64 `json:"high_alert_count"`
	TodayEvents    int64 `json:"today_events"`
}

// AnomalyRequest is the input for the AI anomaly detection service.
type AnomalyRequest struct {
	User      string      `json:"user"`
	Profile   *Profile    `json:"profile"`
	Event     Event       `json:"event"`
	Events    []Event     `json:"recent_events"`
}

// AnomalyResponse is the output from the AI anomaly detection service.
type AnomalyResponse struct {
	AnomalyScore float64       `json:"anomaly_score"`
	IsAnomaly    bool          `json:"is_anomaly"`
	Features     []float64     `json:"features"`
	Explanation  string        `json:"explanation"`
	RiskLevel    string        `json:"risk_level"`
	Suggestions  []string      `json:"suggestions"`
}

// RiskLevel constants
const (
	RiskLow      = "low"
	RiskMedium   = "medium"
	RiskHigh     = "high"
	RiskCritical = "critical"
)

func ScoreToLevel(score int) string {
	switch {
	case score >= 90:
		return RiskCritical
	case score >= 60:
		return RiskHigh
	case score >= 30:
		return RiskMedium
	default:
		return RiskLow
	}
}
