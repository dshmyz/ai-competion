package db

import (
	"ai-sftp-sentinel/config"
	"ai-sftp-sentinel/models"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func Init(cfg *config.Config) (*gorm.DB, error) {
	db, err := gorm.Open(sqlite.Open(cfg.DBPath), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Warn),
	})
	if err != nil {
		return nil, err
	}

	if err := db.AutoMigrate(
		&models.Event{},
		&models.Session{},
		&models.Profile{},
		&models.Alert{},
	); err != nil {
		return nil, err
	}

	return db, nil
}
