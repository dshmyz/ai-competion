---
name: sftp-log-analysis
description: SFTP 日志分析工作流，从日志导入到异常告警的完整流程
---

# SFTP 日志分析工作流

## 触发条件

当需要分析 SFTP 日志、检测异常行为时使用。

## 步骤

### Step 1: 数据导入

```bash
# 单文件导入
curl -X POST localhost:8080/api/import -d '{"path":"/var/log/auth.log"}'

# 或通过日志 tail 实时采集（启动时设置 LOG_FILES 环境变量）
LOG_FILES=/var/log/auth.log,/var/log/secure go run main.go
```

### Step 2: 完整分析

```bash
curl -X POST localhost:8080/api/analyze/run-all
```

此命令自动执行：
1. Session 重建
2. 用户画像构建
3. Isolation Forest 训练
4. 规则检测
5. AI 评分和 LLM 解释

### Step 3: 查看结果

```bash
# 告警列表
curl localhost:8080/api/alerts

# Top 10 告警
curl localhost:8080/api/alerts/top

# 用户画像
curl localhost:8080/api/users
```

### Step 4: 前端查看

浏览器访问 http://localhost:3000 查看 Dashboard。

## 输出

- JSON 告警结果（API 响应）
- 前端 Dashboard 可视化
- 用户画像雷达图
