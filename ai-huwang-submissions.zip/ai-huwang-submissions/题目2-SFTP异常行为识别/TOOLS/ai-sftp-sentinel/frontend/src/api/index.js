import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
})

export default {
  getDashboard: () => api.get('/dashboard'),
  getAlerts: (params) => api.get('/alerts', { params }),
  getTopAlerts: () => api.get('/alerts/top'),
  getUsers: () => api.get('/users'),
  getUserProfile: (user) => api.get(`/users/${user}/profile`),
  getUserEvents: (user, params) => api.get(`/users/${user}/events`, { params }),
  getEvents: (params) => api.get('/events', { params }),
  getSessions: (params) => api.get('/sessions', { params }),
  collectSample: (path) => api.post('/collect/sample', { path }),
  buildSessions: () => api.post('/sessions/build'),
  buildProfiles: () => api.post('/profiles/build'),
  runDetection: () => api.post('/detect'),
  runFullAnalysis: () => api.post('/analyze/run-all'),
}
