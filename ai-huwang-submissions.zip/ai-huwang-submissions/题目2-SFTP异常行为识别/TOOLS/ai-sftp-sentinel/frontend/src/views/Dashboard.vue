<template>
  <div class="dashboard">
    <el-row :gutter="20" class="stat-cards">
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon blue"><el-icon size="32"><User /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total_users }}</div>
            <div class="stat-label">总用户数</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon green"><el-icon size="32"><Connection /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.total_sessions }}</div>
            <div class="stat-label">总会话数</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon orange"><el-icon size="32"><Warning /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.alert_count }}</div>
            <div class="stat-label">异常告警</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-icon red"><el-icon size="32"><CircleClose /></el-icon></div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.high_alert_count }}</div>
            <div class="stat-label">高危事件</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="16">
        <el-card>
          <template #header>
            <span style="font-weight: 600">风险用户排行 Top 10</span>
          </template>
          <div ref="topChartRef" style="height: 360px"></div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <template #header>
            <span style="font-weight: 600">告警等级分布</span>
          </template>
          <div ref="levelChartRef" style="height: 360px"></div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="24">
        <el-card>
          <template #header>
            <div style="display:flex;justify-content:space-between;align-items:center">
              <span style="font-weight:600">最新告警</span>
              <el-button type="primary" size="small" @click="runAnalysis" :loading="analyzing">
                运行完整分析
              </el-button>
            </div>
          </template>
          <el-table :data="topAlerts" stripe style="width: 100%">
            <el-table-column prop="time" label="时间" width="180" />
            <el-table-column prop="user" label="用户" width="100" />
            <el-table-column prop="ip" label="IP" width="150" />
            <el-table-column prop="level" label="风险等级" width="100">
              <template #default="{ row }">
                <el-tag :type="levelType(row.level)">{{ levelLabel(row.level) }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="score" label="风险分" width="80" />
            <el-table-column prop="ai_explain" label="AI 解释" show-overflow-tooltip />
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'
import api from '../api'

const stats = ref({})
const topAlerts = ref([])
const analyzing = ref(false)
const topChartRef = ref(null)
const levelChartRef = ref(null)

const levelType = (l) => ({ critical: 'danger', high: 'danger', medium: 'warning', low: 'success' }[l] || 'info')
const levelLabel = (l) => ({ critical: '严重', high: '高危', medium: '中危', low: '低危' }[l] || l)

async function load() {
  const [dashRes, topRes] = await Promise.all([api.getDashboard(), api.getTopAlerts()])
  stats.value = dashRes.data.data
  topAlerts.value = topRes.data.data
  await nextTick()
  renderCharts()
}

function renderCharts() {
  // Top alerts bar chart
  if (topChartRef.value) {
    const chart = echarts.init(topChartRef.value)
    const data = topAlerts.value.slice(0, 10)
    chart.setOption({
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'category', data: data.map(a => a.user), axisLabel: { rotate: 30 } },
      yAxis: { type: 'value', name: '风险分' },
      series: [{
        type: 'bar',
        data: data.map(a => ({
          value: a.score,
          itemStyle: { color: { critical: '#f56c6c', high: '#e6a23c', medium: '#409eff', low: '#67c23a' }[a.level] || '#909399' }
        })),
        barWidth: '40%',
      }],
      grid: { left: 50, right: 20, bottom: 50 },
    })
  }

  // Level distribution pie chart
  if (levelChartRef.value) {
    const chart = echarts.init(levelChartRef.value)
    const levels = {}
    topAlerts.value.forEach(a => { levels[a.level] = (levels[a.level] || 0) + 1 })
    chart.setOption({
      tooltip: { trigger: 'item' },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        data: [
          { name: '严重', value: levels.critical || 0, itemStyle: { color: '#f56c6c' } },
          { name: '高危', value: levels.high || 0, itemStyle: { color: '#e6a23c' } },
          { name: '中危', value: levels.medium || 0, itemStyle: { color: '#409eff' } },
          { name: '低危', value: levels.low || 0, itemStyle: { color: '#67c23a' } },
        ].filter(d => d.value > 0),
        label: { formatter: '{b}: {c}' },
      }],
    })
  }
}

async function runAnalysis() {
  analyzing.value = true
  try {
    const res = await api.runFullAnalysis()
    ElMessage.success(`分析完成: ${res.data.sessions} 会话, ${res.data.profiles} 画像, ${res.data.alerts} 告警`)
    load()
  } catch (e) {
    ElMessage.error('分析失败: ' + (e.response?.data?.error || e.message))
  } finally {
    analyzing.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.stat-cards .el-card { cursor: pointer; }
.stat-card {
  display: flex;
  align-items: center;
  padding: 10px;
}
.stat-card :deep(.el-card__body) {
  display: flex;
  align-items: center;
  gap: 16px;
}
.stat-icon {
  width: 64px; height: 64px; border-radius: 12px;
  display: flex; align-items: center; justify-content: center; color: #fff;
}
.stat-icon.blue { background: linear-gradient(135deg, #409eff, #337ecc); }
.stat-icon.green { background: linear-gradient(135deg, #67c23a, #529b2e); }
.stat-icon.orange { background: linear-gradient(135deg, #e6a23c, #b88230); }
.stat-icon.red { background: linear-gradient(135deg, #f56c6c, #c45656); }
.stat-value { font-size: 28px; font-weight: 700; color: #303133; }
.stat-label { font-size: 14px; color: #909399; margin-top: 4px; }
</style>
