<template>
  <div>
    <el-card>
      <template #header>
        <span style="font-weight:600;font-size:18px">用户画像</span>
      </template>
      <el-table :data="users" stripe v-loading="loading" style="width:100%" @row-click="showProfile">
        <el-table-column prop="user" label="用户名" width="120" />
        <el-table-column label="活跃时段" width="140">
          <template #default="{ row }">{{ row.active_start }}:00 - {{ row.active_end }}:00</template>
        </el-table-column>
        <el-table-column label="已知IP" min-width="180" show-overflow-tooltip>
          <template #default="{ row }">{{ parseArr(row.known_ips) }}</template>
        </el-table-column>
        <el-table-column label="常用目录" min-width="180" show-overflow-tooltip>
          <template #default="{ row }">{{ parseArr(row.favorite_paths) }}</template>
        </el-table-column>
        <el-table-column label="常用文件类型" min-width="140" show-overflow-tooltip>
          <template #default="{ row }">{{ parseArr(row.favorite_exts) }}</template>
        </el-table-column>
        <el-table-column prop="avg_upload" label="日均上传(MB)" width="130" />
        <el-table-column prop="avg_download" label="日均下载(MB)" width="130" />
        <el-table-column prop="login_count" label="登录次数" width="100" />
        <el-table-column prop="days_tracked" label="跟踪天数" width="100" />
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="`${selectedUser} 用户画像详情`" width="800px">
      <div v-if="selectedProfile">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="活跃时段">{{ selectedProfile.active_start }}:00 - {{ selectedProfile.active_end }}:00</el-descriptions-item>
          <el-descriptions-item label="登录次数">{{ selectedProfile.login_count }}</el-descriptions-item>
          <el-descriptions-item label="日均上传">{{ selectedProfile.avg_upload?.toFixed(2) }} MB</el-descriptions-item>
          <el-descriptions-item label="日均下载">{{ selectedProfile.avg_download?.toFixed(2) }} MB</el-descriptions-item>
          <el-descriptions-item label="会话数">{{ selectedProfile.session_count }}</el-descriptions-item>
          <el-descriptions-item label="跟踪天数">{{ selectedProfile.days_tracked }}</el-descriptions-item>
          <el-descriptions-item label="已知IP" :span="2">{{ parseArr(selectedProfile.known_ips) }}</el-descriptions-item>
          <el-descriptions-item label="常用目录" :span="2">{{ parseArr(selectedProfile.favorite_paths) }}</el-descriptions-item>
          <el-descriptions-item label="常用文件" :span="2">{{ parseArr(selectedProfile.favorite_exts) }}</el-descriptions-item>
        </el-descriptions>
        <div ref="radarRef" style="height:300px;margin-top:20px"></div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import api from '../api'

const users = ref([])
const loading = ref(false)
const dialogVisible = ref(false)
const selectedUser = ref('')
const selectedProfile = ref(null)
const radarRef = ref(null)

function parseArr(v) {
  if (!v) return '—'
  try {
    const arr = JSON.parse(v)
    return Array.isArray(arr) ? arr.join(', ') : v
  } catch { return v }
}

async function load() {
  loading.value = true
  try {
    const res = await api.getUsers()
    users.value = res.data.data
  } finally {
    loading.value = false
  }
}

async function showProfile(row) {
  selectedUser.value = row.user
  const res = await api.getUserProfile(row.user)
  selectedProfile.value = res.data.data
  dialogVisible.value = true
  await nextTick()
  renderRadar()
}

function renderRadar() {
  if (!radarRef.value || !selectedProfile.value) return
  const p = selectedProfile.value
  const chart = echarts.init(radarRef.value)
  chart.setOption({
    title: { text: '用户行为基线', left: 'center' },
    radar: {
      indicator: [
        { name: '活跃时段范围', max: 24 },
        { name: 'IP 多样性', max: 10 },
        { name: '目录多样性', max: 10 },
        { name: '文件类型多样性', max: 10 },
        { name: '日均传输量(MB)', max: Math.max(p.avg_transfer || 100, 50) },
        { name: '会话活跃度', max: Math.max(p.session_count || 10, 10) },
      ],
    },
    series: [{
      type: 'radar',
      data: [{
        value: [
          p.active_end - p.active_start,
          parseArr(p.known_ips).split(',').length,
          parseArr(p.favorite_paths).split(',').length,
          parseArr(p.favorite_exts).split(',').length,
          p.avg_transfer || 0,
          p.session_count || 0,
        ],
        name: p.user,
        areaStyle: { opacity: 0.2 },
      }],
    }],
  })
}

onMounted(load)
</script>
