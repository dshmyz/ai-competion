<template>
  <div>
    <el-card>
      <template #header>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:600;font-size:18px">事件日志</span>
          <div style="display:flex;gap:10px">
            <el-input v-model="filters.user" placeholder="用户名" clearable style="width:120px" />
            <el-select v-model="filters.action" placeholder="操作类型" clearable style="width:120px">
              <el-option label="LOGIN" value="LOGIN" />
              <el-option label="UPLOAD" value="UPLOAD" />
              <el-option label="DOWNLOAD" value="DOWNLOAD" />
              <el-option label="DELETE" value="DELETE" />
            </el-select>
            <el-button type="primary" @click="load">查询</el-button>
          </div>
        </div>
      </template>
      <el-table :data="events" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="time" label="时间" width="180" sortable />
        <el-table-column prop="user" label="用户" width="100" />
        <el-table-column prop="ip" label="来源 IP" width="150" />
        <el-table-column prop="action" label="操作" width="100">
          <template #default="{ row }">
            <el-tag :type="actionType(row.action)" size="small">{{ row.action }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="path" label="文件路径" min-width="250" show-overflow-tooltip />
        <el-table-column prop="size" label="大小" width="100">
          <template #default="{ row }">{{ row.size ? formatSize(row.size) : '—' }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="80" />
        <el-table-column prop="session_id" label="会话ID" width="100" />
      </el-table>
      <div style="margin-top:16px;display:flex;justify-content:flex-end">
        <el-pagination
          v-model:current-page="page"
          :page-size="50"
          :total="total"
          layout="prev, pager, next, total"
          @current-change="load"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const events = ref([])
const total = ref(0)
const page = ref(1)
const loading = ref(false)
const filters = ref({ user: '', action: '' })

const actionType = (a) => ({
  LOGIN: 'primary', UPLOAD: 'warning', DOWNLOAD: 'success', DELETE: 'danger', LOGOUT: 'info'
}[a] || '')

function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

async function load() {
  loading.value = true
  try {
    const res = await api.getEvents({ page: page.value, size: 50, ...filters.value })
    events.value = res.data.data
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>
