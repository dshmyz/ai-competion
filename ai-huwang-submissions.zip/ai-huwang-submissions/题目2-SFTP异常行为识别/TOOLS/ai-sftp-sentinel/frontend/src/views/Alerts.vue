<template>
  <div>
    <el-card>
      <template #header>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:600;font-size:18px">告警列表</span>
          <div style="display:flex;gap:10px">
            <el-select v-model="filters.level" placeholder="风险等级" clearable size="default" style="width:120px">
              <el-option label="严重" value="critical" />
              <el-option label="高危" value="high" />
              <el-option label="中危" value="medium" />
              <el-option label="低危" value="low" />
            </el-select>
            <el-input v-model="filters.user" placeholder="用户名" clearable style="width:140px" />
            <el-button type="primary" @click="load">查询</el-button>
          </div>
        </div>
      </template>
      <el-table :data="alerts" stripe v-loading="loading" style="width:100%">
        <el-table-column prop="time" label="时间" width="180" sortable />
        <el-table-column prop="user" label="用户" width="100" />
        <el-table-column prop="ip" label="来源 IP" width="150" />
        <el-table-column prop="level" label="风险等级" width="100">
          <template #default="{ row }">
            <el-tag :type="levelType(row.level)" effect="dark">{{ levelLabel(row.level) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="score" label="总分" width="80" sortable />
        <el-table-column prop="rule_score" label="规则分" width="80" />
        <el-table-column prop="ai_score" label="AI分" width="80" />
        <el-table-column label="告警原因" min-width="250" show-overflow-tooltip>
          <template #default="{ row }">
            <span>{{ parseReasons(row.reasons) }}</span>
          </template>
        </el-table-column>
        <el-table-column label="AI 解释" min-width="300" show-overflow-tooltip>
          <template #default="{ row }">
            <span>{{ row.ai_explain || '—' }}</span>
          </template>
        </el-table-column>
      </el-table>
      <div style="margin-top:16px;display:flex;justify-content:flex-end">
        <el-pagination
          v-model:current-page="page"
          :page-size="20"
          :total="total"
          layout="prev, pager, next, total"
          @current-change="load"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const alerts = ref([])
const total = ref(0)
const page = ref(1)
const loading = ref(false)
const filters = ref({ level: '', user: '' })

const levelType = (l) => ({ critical: 'danger', high: 'danger', medium: 'warning', low: 'success' }[l] || 'info')
const levelLabel = (l) => ({ critical: '严重', high: '高危', medium: '中危', low: '低危' }[l] || l)

function parseReasons(r) {
  if (!r) return '—'
  try {
    const arr = JSON.parse(r)
    return Array.isArray(arr) ? arr.join('；') : r
  } catch { return r }
}

async function load() {
  loading.value = true
  try {
    const res = await api.getAlerts({ page: page.value, size: 20, ...filters.value })
    alerts.value = res.data.data
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>
