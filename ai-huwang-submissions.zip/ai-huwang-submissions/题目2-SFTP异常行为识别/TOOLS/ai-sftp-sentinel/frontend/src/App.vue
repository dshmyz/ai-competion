<template>
  <el-config-provider :locale="zhCn">
    <el-container class="app-container">
      <el-aside width="220px" class="app-aside">
        <div class="logo">
          <h2>🛡️ Sentinel</h2>
          <p>AI-SFTP 安全分析</p>
        </div>
        <el-menu
          :default-active="$route.path"
          router
          background-color="#1d1e2c"
          text-color="#a3a6b4"
          active-text-color="#409eff"
        >
          <el-menu-item index="/">
            <el-icon><Odometer /></el-icon>
            <span>仪表盘</span>
          </el-menu-item>
          <el-menu-item index="/alerts">
            <el-icon><Warning /></el-icon>
            <span>告警列表</span>
          </el-menu-item>
          <el-menu-item index="/users">
            <el-icon><User /></el-icon>
            <span>用户画像</span>
          </el-menu-item>
          <el-menu-item index="/events">
            <el-icon><Document /></el-icon>
            <span>事件日志</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main class="app-main">
        <router-view />
      </el-main>
    </el-container>
  </el-config-provider>
</template>

<script setup>
import zhCn from 'element-plus/es/locale/lang/zh-cn'
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f0f2f5;
}
.app-container {
  height: 100vh;
}
.app-aside {
  background: #1d1e2c;
  overflow-y: auto;
}
.logo {
  padding: 20px;
  text-align: center;
  color: #fff;
  border-bottom: 1px solid rgba(255,255,255,0.1);
}
.logo h2 {
  font-size: 20px;
  margin-bottom: 4px;
}
.logo p {
  font-size: 12px;
  color: #a3a6b4;
}
.app-main {
  padding: 20px;
  overflow-y: auto;
}
</style>
