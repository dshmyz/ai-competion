import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', name: 'Dashboard', component: () => import('../views/Dashboard.vue') },
  { path: '/alerts', name: 'Alerts', component: () => import('../views/Alerts.vue') },
  { path: '/users', name: 'Users', component: () => import('../views/Users.vue') },
  { path: '/events', name: 'Events', component: () => import('../views/Events.vue') },
]

export default createRouter({
  history: createWebHistory(),
  routes,
})
