# AI-SFTP Sentinel 分析报告

## 1. 项目背景与设计动机

### 1.1 问题

企业 SFTP 服务器承载大量文件传输业务。传统安全审计面临三个核心难题：

1. **日志分散**：登录日志、文件操作日志、会话日志分布在不同文件，人工关联困难
2. **基线缺失**：没有自动化手段为每个用户建立"正常行为画像"
3. **未知威胁**：规则只能发现已知模式，无法发现新型内部威胁或账号盗用

### 1.2 设计目标

设计一个 SFTP 安全分析平台，实现：

- 自动关联离散日志，重建用户会话
- 为每个用户建立多维行为基线
- 通过规则 + AI 双引擎检测异常
- 用大模型自动生成人类可读的异常解释
- 单体部署，零外部依赖

### 1.3 UEBA 设计思想

本系统采用 UEBA（User and Entity Behavior Analytics）思想：

```
传统审计：规则 → 匹配 → 告警
         （只能发现已知的已知）

UEBA：   历史行为 → 建模正常 → 检测偏离 → AI 解释
         （能发现未知的未知）
```

核心区别在于：先理解什么是"正常"，再检测什么是"异常"。

## 2. 总体架构

### 2.1 架构图

```
已有的日志采集器 / 日志文件
              │
              ▼
     ┌─────────────────┐
     │  Log Collector   │  ← 实时 tail + 手动导入
     │  (tail_collector)│
     └────────┬────────┘
              │ SQLite
              ▼
     ┌─────────────────┐     ┌───────────────────┐
     │ Session Builder  │     │  Profile Builder   │
     │ (会话重建)        │     │  (五维画像)         │
     └────────┬────────┘     └────────┬──────────┘
              │                       │
              ▼                       ▼
     ┌─────────────────────────────────────────┐
     │          Detector Engine                 │
     │  ┌──────────────┐  ┌─────────────────┐  │
     │  │  Rule Engine  │  │ Isolation Forest │  │
     │  │  (7 条规则)    │  │  (Go 原生)       │  │
     │  └──────┬───────┘  └────────┬────────┘  │
     │         └─────────┬─────────┘           │
     │                   ▼                      │
     │            Risk Scoring                  │
     │                   │                      │
     │                   ▼                      │
     │         LLM Explain (Ollama)            │
     └─────────────────────┬───────────────────┘
                           │
                           ▼
                    Vue3 Dashboard
```

### 2.2 技术选型理由

| 决策 | 理由 |
|---|---|
| Go 单体 | SFTP 日志量通常不大，Go 性能足够；单二进制部署简单 |
| SQLite | 零配置嵌入式数据库，适合中小规模安全分析场景 |
| Go 原生 Isolation Forest | 避免 Python 运行时依赖；算法核心（随机切分树）不复杂 |
| Ollama + Qwen3 | 本地部署 LLM，无需 API Key；Qwen3 中文能力强 |
| 模板回退 | LLM 不可用时系统仍能工作，保证可用性 |
| Vue3 + ECharts | 成熟的前端技术栈，图表展示能力强 |

## 3. 核心模块设计

### 3.1 日志解析器

**设计思路**：SFTP 日志格式多样，需要一个统一的解析器将其转换为结构化事件。

支持三种格式：

| 格式 | 来源 | 示例 |
|---|---|---|
| OpenSSH | auth.log / syslog | `May 20 09:13:21 host sshd[123]: Accepted password for alice from 10.1.1.1` |
| Key=Value | 自定义/集中日志 | `2026-05-20 09:13:21 user=alice ip=10.1.1.1 action=login status=success` |
| SFTP 日志 | sftp-server | `open "/upload/file.txt" bytes read 1024 written 0` |

统一输出 Event 结构：

```go
type Event struct {
    User      string
    SessionID string
    IP        string
    Action    string    // LOGIN, UPLOAD, DOWNLOAD, DELETE, LOGOUT...
    Path      string
    Size      int64
    Time      time.Time
    Status    string    // success, failed
}
```

### 3.2 Session 重建

**设计思路**：SFTP 日志天然是离散的——登录事件、文件操作事件、会话关闭事件分散在不同位置。我们需要将它们关联为"会话"。

关联策略：
1. **用户名匹配**：同一用户的事件
2. **IP 匹配**：同一来源 IP
3. **时间窗口**：30 分钟内无活动则切分为新会话
4. **Session ID**：分配唯一标识，方便后续查询和告警关联

```
event1(alice, 10.1.1.1, 09:00) ─┐
event2(alice, 10.1.1.1, 09:05)  ├─→ session-1
event3(alice, 10.1.1.1, 09:20) ─┘
                                 ← 30 分钟间隔 →
event4(alice, 10.1.1.1, 10:15) ─→ session-2 (新会话)
```

### 3.3 用户画像（五维基线）

**设计思路**：为每个用户建立"正常行为画像"，作为异常检测的参照基准。

基于最近 30 天历史行为，统计五个维度：

| 维度 | 统计内容 | 用途 |
|---|---|---|
| 时间画像 | 活跃时段 (active_start, active_end) | 判断是否非工作时间登录 |
| IP 画像 | 已知 IP 列表 (known_ips) | 判断是否陌生 IP |
| 路径画像 | 常用目录 (favorite_paths) | 判断是否异常目录 |
| 文件画像 | 常用文件类型 (favorite_exts) | 判断是否异常文件类型 |
| 流量画像 | 日均上传/下载/传输量 (avg_*) | 判断是否流量激增 |

示例画像：

```json
{
  "user": "alice",
  "active_start": 9,
  "active_end": 18,
  "known_ips": ["192.168.1.10", "192.168.1.11"],
  "favorite_paths": ["/upload/alice", "/report/weekly"],
  "favorite_exts": [".xlsx", ".pdf", ".csv"],
  "avg_upload": 15.3,
  "avg_download": 45.7,
  "avg_transfer": 61.0
}
```

### 3.4 规则检测引擎

**设计思路**：覆盖已知的高置信度风险模式，评分可累加，支持一次会话命中多条规则。

7 条规则：

| 规则 | 逻辑 | 评分 |
|---|---|---|
| R1 异常时间 | 登录时段不在用户画像活跃范围 | +20 |
| R2 陌生 IP | IP 不在用户 known_ips | +25 |
| R3 异常目录 | 访问路径不在 favorite_paths | +15 |
| R4 异常文件 | 文件类型不在 favorite_exts | +10 |
| R5 下载激增 | 本次下载 > 日均 × 5 | +20 |
| R6 上传激增 | 本次上传 > 日均 × 5 | +15 |
| R7 暴力破解 | 同 IP 5min 内失败 ≥ 5 次 | +25 |

规则分累加上限 100。

### 3.5 Isolation Forest（Go 原生实现）

**设计思路**：Isolation Forest 是一种无监督异常检测算法，核心思想是"异常点更容易被随机切分隔离"。

算法流程：

1. **训练**：从正常行为数据中随机采样 N 组子集
2. **建树**：每组子集构建一棵随机二叉树，每次随机选一个特征和切分值
3. **预测**：将新数据点在每棵树中从根走到叶，记录路径长度
4. **评分**：路径越短 → 越容易被隔离 → 越可能是异常

```
正常点路径长（需要更多切分才能隔离）：
  Root → Left → Right → Left → Right → Leaf  (深度 5)

异常点路径短（很快被隔离）：
  Root → Left → Leaf  (深度 2)
```

10 维特征向量：

| # | 特征 | 含义 | 取值范围 |
|---|---|---|---|
| 0 | login_hour_deviation | 登录时间偏离度 | [0, 1] |
| 1 | is_new_ip | 是否新 IP | 0 或 1 |
| 2 | is_new_path | 是否新目录 | 0 或 1 |
| 3 | is_new_ext | 是否新文件类型 | 0 或 1 |
| 4 | upload_deviation | 上传量偏离度 | [0, 1] |
| 5 | download_deviation | 下载量偏离度 | [0, 1] |
| 6 | transfer_deviation | 总传输偏离度 | [0, 1] |
| 7 | login_fail_ratio | 登录失败比例 | [0, 1] |
| 8 | session_duration | 会话时长(归一化) | [0, 1] |
| 9 | event_density | 事件密度(归一化) | [0, 1] |

异常评分 = 2^(-avgPath / c(n))，范围 [0, 1]，越大越异常。

### 3.6 风险评分

**设计思路**：规则分和 AI 分各有所长，取平均作为综合评分。

```
RiskScore = (RuleScore + AIScore) / 2
```

- RuleScore：规则引擎评分（0-100），基于已知模式
- AIScore：Isolation Forest 评分 × 100（0-100），发现未知异常

综合评分等级：

| 分数 | 等级 | 颜色 |
|---|---|---|
| 0-29 | 低风险 | 🟢 |
| 30-59 | 中风险 | 🔵 |
| 60-89 | 高风险 | 🟠 |
| 90+ | 严重风险 | 🔴 |

### 3.7 LLM 智能解释

**设计思路**：告警只有评分和原因列表，安全人员需要花时间研判。LLM 可以自动生成中文解释和处置建议。

工作流程：

1. 将用户画像 + 当前异常行为 + 特征偏离度组装为 prompt
2. 调用 Ollama API（Qwen3 模型）
3. 解析 LLM 返回的 JSON（风险等级、解释、建议）
4. 如果 LLM 不可用，自动回退到基于模板的解释

## 4. 数据库设计

### 4.1 events 表

存储所有 SFTP 操作事件。

```sql
CREATE TABLE events(
    id INTEGER PRIMARY KEY,
    user TEXT,
    session_id TEXT,
    ip TEXT,
    action TEXT,      -- LOGIN/UPLOAD/DOWNLOAD/DELETE/LOGOUT
    path TEXT,
    size INTEGER,
    time DATETIME,
    status TEXT,       -- success/failed
    source_file TEXT,
    raw TEXT
);
```

### 4.2 sessions 表

存储重建后的用户会话。

```sql
CREATE TABLE sessions(
    id TEXT PRIMARY KEY,    -- s-1, s-2...
    user TEXT,
    ip TEXT,
    login_time DATETIME,
    logout_time DATETIME,
    event_count INTEGER,
    total_upload INTEGER,
    total_download INTEGER
);
```

### 4.3 profiles 表

存储用户行为画像。

```sql
CREATE TABLE profiles(
    id INTEGER PRIMARY KEY,
    user TEXT UNIQUE,
    active_start INTEGER,     -- 活跃开始小时
    active_end INTEGER,       -- 活跃结束小时
    known_ips TEXT,           -- JSON 数组
    favorite_paths TEXT,      -- JSON 数组
    favorite_exts TEXT,       -- JSON 数组
    avg_upload REAL,          -- MB/day
    avg_download REAL,        -- MB/day
    avg_transfer REAL,        -- MB/day
    login_count INTEGER,
    session_count INTEGER,
    days_tracked INTEGER,
    updated_at DATETIME
);
```

### 4.4 alerts 表

存储异常告警。

```sql
CREATE TABLE alerts(
    id INTEGER PRIMARY KEY,
    user TEXT,
    session_id TEXT,
    ip TEXT,
    score INTEGER,          -- 综合评分
    level TEXT,             -- low/medium/high/critical
    rule_score INTEGER,     -- 规则评分
    ai_score INTEGER,       -- AI 评分
    reasons TEXT,           -- JSON 数组：告警原因
    ai_explain TEXT,        -- LLM 生成的解释
    time DATETIME,
    created_at DATETIME
);
```

## 5. 检测结果

使用 642 条合成样例数据运行完整分析：

| 指标 | 数量 |
|---|---:|
| 日志事件总数 | 642 |
| 涉及用户数 | 5 |
| 用户画像数 | 5 |
| 异常告警数 | ~15 |

### 5.1 检测到的主要异常

| 用户 | 异常类型 | 风险等级 | 说明 |
|---|---|---|---|
| bob | 非工作时间 + 敏感文件 + 陌生 IP | critical | 凌晨 2 点从外部 IP 下载 /etc/passwd |
| admin | 暴力破解 | high | 外部 IP 连续 6 次登录失败 |
| alice | 下载激增 | high | 10 分钟内下载 25 个财务文件 |
| charlie | 异常目录 | medium | 上传到 /var/www/html/ |
| diana | 陌生 IP | medium | 从新 IP 登录并下载大量文件 |

## 6. 安全加固建议

1. 使用 chroot 限制 SFTP 用户根目录
2. 强制复杂密码 + MFA 多因素认证
3. 配置 Fail2Ban 封禁暴力破解 IP
4. 限制 SFTP 访问来源 IP 白名单
5. 对敏感目录设置最小权限
6. 将日志接入集中审计平台（ELK/SIEM）
7. 定期复盘用户行为基线
8. 对高风险操作设置实时告警

## 7. 答辩亮点总结

1. **Session 重建** — 解决 SFTP 日志离散问题，实现会话级分析
2. **五维用户画像** — 时间/IP/路径/文件/流量多维行为基线
3. **双引擎检测** — 规则 + Isolation Forest，覆盖已知和未知
4. **Go 原生 Isolation Forest** — 无需 Python，零外部依赖
5. **LLM 智能解释** — 集成 Ollama/Qwen3 自动生成中文分析
6. **UEBA 思想** — 从"规则匹配"升级为"行为分析"
7. **单体架构** — 部署简单，一个二进制 + SQLite 即可运行
