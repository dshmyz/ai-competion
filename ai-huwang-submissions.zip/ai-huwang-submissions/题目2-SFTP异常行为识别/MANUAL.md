# AI-SFTP Sentinel 使用说明

## 1. 项目简介

AI-SFTP Sentinel 是一个基于 Go 语言单体架构实现的 SFTP 用户行为安全分析平台。采用 UEBA（用户与实体行为分析）思想，通过用户画像建模、规则检测、Isolation Forest AI 异常检测和大模型智能解释四层能力，实现 SFTP 用户行为的智能分析与告警。

**技术特点：全 Go 实现，无 Python 依赖，单二进制部署。**

## 2. 设计思路

### 2.1 为什么选择 UEBA

传统安全审计基于规则，只能发现"已知的已知"。UEBA 的核心思想是：

1. **先建模正常**：通过历史行为为每个用户建立"正常画像"
2. **再检测偏离**：任何偏离正常画像的行为都值得重点关注
3. **多维评估**：不只看单一维度，而是时间、IP、路径、文件、流量综合评估

### 2.2 为什么选择 Go 单体架构

| 考量 | 说明 |
|---|---|
| 部署简单 | 单二进制 + SQLite，无需外部依赖 |
| 性能足够 | SFTP 日志量通常不大，Go 完全足够 |
| 并发天然 | Go goroutine 适合日志 tail 和后台分析 |
| AI 能力 | Isolation Forest 核心算法简单，Go 可原生实现 |
| 比赛展示 | 单体架构比微服务更清晰，答辩更易解释 |

### 2.3 AI 检测的设计选择

系统采用"**规则 + AI 双引擎**"设计：

- **规则引擎**：覆盖已知风险模式（暴力破解、异常时间、敏感文件等），可解释性强
- **Isolation Forest**：发现规则覆盖不到的未知异常，不需要标注数据
- **LLM 解释**：将 AI 检测结果翻译为人类可理解的语言，降低研判成本

Isolation Forest 的核心原理：随机切分特征空间，异常点因为位于稀疏区域，会被更快"隔离"（平均路径更短）。

## 3. 环境要求

| 组件 | 要求 |
|---|---|
| Go | 1.21+（需要 CGO 支持 SQLite） |
| Node.js | 18+（前端构建） |
| Ollama | 可选，用于 LLM 解释功能 |
| 操作系统 | Linux / macOS |

## 4. 目录结构

```text
ai-sftp-sentinel/
├── backend/                        # Go 后端（全部业务逻辑 + AI）
│   ├── main.go                     # 入口：初始化 DB → 训练模型 → 启动采集 → 启动服务
│   ├── config/config.go            # 配置管理
│   ├── db/database.go              # SQLite 数据库初始化
│   ├── models/models.go            # 数据模型（Event/Session/Profile/Alert）
│   ├── parser/sftp_parser.go       # 多格式日志解析器
│   ├── logcollector/
│   │   └── tail_collector.go       # 实时日志 tail 采集器
│   ├── sessionbuilder/
│   │   └── builder.go              # Session 重建引擎
│   ├── services/
│   │   ├── profile_builder.go      # 五维用户画像构建
│   │   ├── detector.go             # 7 条规则检测引擎
│   │   ├── anomaly_forest.go       # Go 原生 Isolation Forest
│   │   ├── llm_client.go           # Ollama LLM 调用 + 模板回退
│   │   └── risk_scorer.go          # 风险评分整合
│   ├── handlers/handlers.go        # HTTP API 处理器
│   └── router/router.go            # 路由
├── frontend/                       # Vue 3 前端
│   └── src/views/                  # Dashboard / Alerts / Users / Events
├── scripts/
│   ├── start.sh                    # 一键启动脚本
│   └── seed_data.py                # 样例数据生成器
├── data/
│   └── sample.log                  # 642 条样例日志
└── README.md
```

## 5. 快速启动

### 5.1 方式一：一键启动（推荐）

```bash
cd scripts
./start.sh ../data/sample.log
```

启动后：
- 前端界面：http://localhost:3000
- 后端 API：http://localhost:8080

### 5.2 方式二：分步启动

**Step 1：编译运行后端**

```bash
cd backend
go mod tidy
# 导入样例日志
LOG_FILES=../data/sample.log go run main.go
```

**Step 2：手动导入日志并分析**

```bash
# 导入日志
curl -X POST http://localhost:8080/api/import \
  -H "Content-Type: application/json" \
  -d '{"path": "/absolute/path/to/sample.log"}'

# 一键完整分析（Session 重建 → 画像 → 训练模型 → 检测 → AI 评分）
curl -X POST http://localhost:8080/api/analyze/run-all
```

**Step 3：启动前端**

```bash
cd frontend
npm install
npm run dev
```

### 5.3 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| PORT | 8080 | 后端监听端口 |
| DB_PATH | sentinel.db | SQLite 数据库路径 |
| LOG_FILES | (空) | 要监控的日志文件，逗号分隔 |
| OLLAMA_URL | http://localhost:11434 | Ollama 服务地址 |
| OLLAMA_MODEL | qwen3:8b | LLM 模型名称 |

## 6. 使用流程

### 6.1 实时监控模式

设置 `LOG_FILES` 环境变量后启动，系统会自动：

1. 每 30 秒扫描日志文件新增内容
2. 解析并导入新事件
3. 需手动触发 Session 重建、画像更新和检测

### 6.2 手动分析模式

```bash
# 1. 导入日志
curl -X POST localhost:8080/api/import -d '{"path":"/path/to/auth.log"}'

# 2. 一键分析
curl -X POST localhost:8080/api/analyze/run-all
```

### 6.3 生成更多样例数据

```bash
cd scripts
python3 seed_data.py ../data/sample_full.log 14  # 生成 14 天数据
```

## 7. API 接口详解

### 数据导入

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | /api/import | 导入单个日志文件（全量读取） |
| POST | /api/collect | 批量导入多个日志文件 |

### 分析流水线

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | /api/sessions/build | 从事件重建 Session |
| POST | /api/profiles/build | 从历史行为构建用户画像 |
| POST | /api/detect | 运行规则异常检测 |
| POST | /api/forest/train | 重新训练 Isolation Forest |
| POST | /api/analyze/run-all | 一键完整分析（上述全部 + AI 评分） |

### 查询接口

| 方法 | 路径 | 参数 | 说明 |
|---|---|---|---|
| GET | /api/dashboard | — | 仪表盘统计 |
| GET | /api/alerts | level, user, page, size | 告警列表 |
| GET | /api/alerts/top | — | Top 10 告警 |
| GET | /api/users | — | 用户画像列表 |
| GET | /api/users/:user/profile | — | 单用户画像详情 |
| GET | /api/users/:user/events | page, size | 用户事件列表 |
| GET | /api/events | user, action, page, size | 全部事件 |
| GET | /api/sessions | page, size | Session 列表 |
| GET | /api/ai/stats | — | Isolation Forest 模型状态 |

## 8. 检测规则说明

| 编号 | 规则 | 触发条件 | 风险分 |
|---|---|---|---|
| R1 | 异常时间登录 | 登录时间不在 06:00-00:00 | +20 |
| R2 | 陌生 IP 登录 | IP 不在历史已知 IP 列表 | +25 |
| R3 | 异常目录访问 | 目录不在常用目录列表 | +15 |
| R4 | 异常文件类型 | 文件类型不在常用类型列表 | +10 |
| R5 | 下载量激增 | 本次下载量 > 日均 × 5 | +20 |
| R6 | 上传量激增 | 本次上传量 > 日均 × 5 | +15 |
| R7 | 暴力破解 | 同 IP 5 分钟内失败 ≥ 5 次 | +25 |

## 9. 风险等级

| 综合分 | 等级 | 颜色 | 建议 |
|---|---|---|---|
| 0-29 | 低风险 | 绿色 | 继续监控 |
| 30-59 | 中风险 | 蓝色 | 建议排查 |
| 60-89 | 高风险 | 橙色 | 需要处理 |
| 90+ | 严重风险 | 红色 | 立即响应 |

综合分 = (规则分 + AI 分) / 2

## 10. 注意事项

1. 首次启动时 Isolation Forest 会使用合成数据训练，建议在导入足够历史数据后重新训练
2. LLM 解释功能依赖 Ollama，未安装时自动使用模板解释
3. SQLite 适合中小规模部署，大规模场景建议换 PostgreSQL
4. 日志解析器支持三种格式，特殊格式需修改 `parser/sftp_parser.go`
5. 日志 tail 采集支持日志轮转（文件截断时自动重置偏移量）
