# 题目 3：Nginx 安全防护报告

## 1. 项目背景

Nginx 是常见 Web 服务器和反向代理组件。错误配置可能导致版本泄露、目录浏览、弱 TLS、缺少安全响应头、上传风险、代理头伪造、访问日志不足等问题。本题从安全防护角度评估 Nginx 服务配置，识别风险并给出加固方案。

## 2. 防护目标

1. 检查 Nginx 配置中的安全风险；
2. 形成自动化配置检查工具；
3. 输出风险等级和修复建议；
4. 给出加固配置示例；
5. 形成防守成果报告。

## 3. 检查范围

| 检查项 | 风险 |
|---|---|
| server_tokens | 版本泄露 |
| TLS 协议 | 弱协议被利用 |
| 安全响应头 | XSS、点击劫持、MIME 嗅探 |
| autoindex | 目录列表泄露 |
| client_max_body_size | 大文件上传或 DoS 风险 |
| access_log/error_log | 审计不足 |
| location 配置 | 敏感目录暴露 |
| 限速配置 | 爆破或 CC 攻击 |
| 反向代理头 | Host/XFF 伪造风险 |
| HSTS | 未启用严格传输安全 |
| OCSP Stapling | 证书吊销检查效率 |
| proxy_hide_header | 后端技术栈泄露 |

## 4. 工具说明

使用 `TOOLS/nginx_security_check.py` 检查 Nginx 配置：

```bash
python3 TOOLS/nginx_security_check.py TOOLS/sample_nginx.conf TOOLS/check_result.json
```

工具会输出 JSON：

```json
{
  "summary": {
    "total_findings": 8,
    "high": 2,
    "medium": 4,
    "low": 2
  },
  "findings": []
}
```

## 5. 主要发现

### 5.1 server_tokens 未关闭

如果未配置 `server_tokens off;`，Nginx 可能在错误页或响应头中暴露版本信息。

风险等级：medium。

建议：

```nginx
server_tokens off;
```

### 5.2 TLS 协议不安全

如果启用 TLSv1 或 TLSv1.1，可能存在弱协议风险。

建议：

```nginx
ssl_protocols TLSv1.2 TLSv1.3;
```

### 5.3 缺少安全响应头

建议配置：

```nginx
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```

### 5.4 目录浏览风险

如果配置 `autoindex on;`，可能导致目录文件被列出。

建议关闭：

```nginx
autoindex off;
```

### 5.5 缺少限速

如果没有 `limit_req_zone` 和 `limit_req`，容易遭受暴力破解和 CC 攻击。

建议：

```nginx
limit_req_zone $binary_remote_addr zone=login_limit:10m rate=5r/m;
limit_req zone=login_limit burst=10 nodelay;
```

## 6. 加固配置摘要

完整加固配置见：

```text
TOOLS/nginx_hardening.conf
```

加固重点：

1. 关闭版本泄露；
2. 使用 TLSv1.2/TLSv1.3；
3. 增加安全响应头；
4. 关闭目录浏览；
5. 限制上传大小；
6. 配置访问日志；
7. 保护敏感文件；
8. 增加请求限速；
9. 安全设置反向代理头。

## 7. 防护效果

加固后可以降低以下风险：

- 版本信息泄露；
- 弱 TLS 协议攻击；
- 目录文件泄露；
- XSS 和点击劫持风险；
- 大文件上传 DoS；
- 暴力破解和 CC 攻击；
- 敏感配置文件泄露；
- 日志审计缺失。

## 8. 后续建议

1. 将 Nginx 日志接入集中日志平台；
2. 配合 WAF 防护常见 Web 攻击；
3. 使用自动化工具定期扫描配置；
4. 对公网入口进行资产梳理；
5. 定期更新 Nginx 和 OpenSSL；
6. 使用基线检查工具纳入 CI/CD。

## 9. 结论

本题完成了 Nginx 安全配置检查、防护建议和加固配置示例。通过自动化检查工具和防守报告，可以系统性识别 Nginx 配置风险，并形成可落地的整改方案。
