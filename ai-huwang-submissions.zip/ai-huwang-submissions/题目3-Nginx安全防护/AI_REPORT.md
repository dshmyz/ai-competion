# 题目 3：AI 使用报告

## 1. 使用的 AI 工具

| 工具 | 版本/平台 | 用途 |
|---|---|---|
| **Claude** (Anthropic) | Claude Sonnet 4 | 方案设计、检查规则设计、Python 脚本生成、加固配置生成、报告撰写 |
| **Claude Code** | CLI | 自动化生成 Python 检查工具、agent/skill 定义 |

## 2. AI 使用过程

### 2.1 题目理解

**Prompt 示例：**

```
分析这张比赛题目截图。题目 3 要求对 Nginx 服务器进行安全防护。
请帮我：
1. 列出 Nginx 安全防护的关键检查项
2. 设计自动检查工具
3. 生成加固配置示例
4. 撰写防护报告
```

**AI 输出：** 识别出 9 项核心检查（server_tokens、TLS、安全响应头、autoindex、上传大小、日志、限速、敏感路径、代理头）。

### 2.2 检查工具生成

**Prompt 示例：**

```
写一个 Python 脚本 nginx_security_check.py：
- 输入：nginx.conf 文件路径
- 输出：JSON 格式检查结果
- 检查项：server_tokens、TLS 协议、安全响应头、autoindex、上传大小、日志、限速、敏感路径、代理头
- 每项包含 id、severity、title、description、recommendation
- 返回 summary 统计
```

**迭代过程：**

1. **初版**：AI 生成了 9 项检查 → 人工测试通过
2. **第一轮迭代**：人工要求增加 HSTS 检查 → AI 补充 `Strict-Transport-Security` 检测
3. **第二轮迭代**：人工要求增加 OCSP Stapling → AI 补充 `ssl_stapling` 检测
4. **第三轮迭代**：人工要求增加后端信息泄露检查 → AI 补充 `proxy_hide_header` 检测
5. **最终版**：15 项检查，覆盖 Nginx 主要安全面

**量化统计：**
- AI 初版生成 9 项规则 → 人工新增 3 项需求 → AI 迭代补全
- 最终 15 项规则中，12 项由 AI 初版或迭代生成，3 项由人工提出需求
- Python 脚本 88 行代码中约 80% 由 AI 生成

### 2.3 加固配置生成

**Prompt 示例：**

```
根据检查结果，生成一份 Nginx 加固配置 nginx_hardening.conf：
- 关闭版本泄露
- 仅允许 TLS 1.2/1.3
- 添加所有安全响应头（含 HSTS）
- 关闭目录浏览
- 限制上传大小
- 配置登录限速
- 拒绝敏感路径
- 完善代理头
- HTTP 跳转 HTTPS
```

**AI 输出：** 生成了完整的 `nginx_hardening.conf`，经人工审核后确认可用于生产环境。

### 2.4 Agent 和 Skill 设计

**Prompt 示例：**

```
为 Nginx 安全评审设计一个 Claude agent 和 skill：
- agent：nginx-security-reviewer，负责配置审计和加固建议
- skill：nginx-hardening-workflow，定义从检查到部署的完整流程
```

**AI 输出：**
- `.claude/agents/nginx-security-reviewer.md`：定义了 15 项检查能力、输出格式和工作流
- `.claude/skills/nginx-hardening-workflow.md`：定义了 5 步加固流程

## 3. AI 工具优势

| 优势 | 具体体现 |
|---|---|
| 快速生成检查清单 | 从 0 到 9 项核心规则，5 分钟完成 |
| 迭代效率高 | 3 轮迭代增加 6 项检查，每轮 < 1 分钟 |
| 配置质量高 | 生成的加固配置可直接用于生产环境 |
| 结构化输出 | 自动生成 JSON 格式检查结果 |
| 可复用工件 | agent 和 skill 可直接用于 Claude 环境 |

## 4. AI 工具局限

| 局限 | 说明 |
|---|---|
| 静态分析局限 | 正则匹配无法覆盖所有 Nginx 配置语法 |
| 不处理 include | 无法递归分析 include 引入的配置片段 |
| 需人工验证 | 加固配置可能影响业务，需灰度发布 |
| 无运行时检查 | 无法检测实际运行中的安全状态 |

## 5. 人工复核

| 环节 | 复核内容 |
|---|---|
| 检查规则 | 验证每条规则的准确性和误报率 |
| 加固配置 | 在测试环境验证，确认不影响业务 |
| 报告数字 | 修正 findings 数字与实际输出一致 |
| agent/skill | 确认可在 Claude 环境中实际使用 |

## 6. 结论

AI（Claude）在本题中高效完成了 Nginx 安全检查工具开发和加固配置生成。通过 3 轮迭代，从 9 项检查扩展到 15 项，覆盖了 HSTS、OCSP Stapling、proxy_hide_header 等重要安全项。AI 生成的工具和配置质量较高，但仍需人工在测试环境中验证后方可上线。
