# 题目 3 TOOLS 使用说明

## 文件说明

```text
nginx_security_check.py   # Nginx 配置安全检查脚本
sample_nginx.conf         # 存在风险的样例配置
nginx_hardening.conf      # 安全加固配置示例
check_result.json         # 样例检查结果
ai_artifacts/             # AI skill 和 agent 说明
```

## 运行

```bash
python3 nginx_security_check.py sample_nginx.conf check_result.json
```

## 说明

该工具进行静态配置检查，不会修改系统配置。生产环境上线前需使用：

```bash
nginx -t
```

验证配置语法，并经过灰度发布。
