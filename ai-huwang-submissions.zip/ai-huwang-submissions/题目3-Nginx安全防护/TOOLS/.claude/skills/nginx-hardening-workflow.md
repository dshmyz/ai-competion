---
name: nginx-hardening-workflow
description: Nginx 安全加固工作流，从配置检查到加固部署
---

# Nginx 安全加固工作流

## 触发条件

当需要对 Nginx 服务器进行安全检查和加固时使用。

## 步骤

### Step 1: 获取当前配置

```bash
# 方式一：直接读取配置文件
cat /etc/nginx/nginx.conf

# 方式二：导出完整生效配置
nginx -T > current_nginx.conf
```

### Step 2: 安全检查

```bash
python3 nginx_security_check.py current_nginx.conf check_result.json
```

查看检查结果：
- `summary.total_findings` — 发现总数
- `summary.high` — 高危数量
- `findings[]` — 详细发现列表

### Step 3: 生成加固配置

根据检查结果，参考 `nginx_hardening.conf` 生成加固配置。关键加固项：

```nginx
server_tokens off;
ssl_protocols TLSv1.2 TLSv1.3;
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
autoindex off;
client_max_body_size 10m;
limit_req_zone $binary_remote_addr zone=login_limit:10m rate=5r/m;
proxy_hide_header X-Powered-By;
```

### Step 4: 验证和部署

```bash
# 语法检查
nginx -t

# 重新加载
nginx -s reload

# 验证效果
curl -I https://example.com
```

## 输出

- `check_result.json` — 检查结果
- `nginx_hardening.conf` — 加固配置
- `DEF_REPORT.md` — 防护报告
