#!/usr/bin/env python3
import json
import re
import sys


def strip_comments(text):
    lines = []
    for line in text.splitlines():
        line = re.sub(r"#.*$", "", line).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def finding(fid, severity, title, description, recommendation):
    return {"id": fid, "severity": severity, "title": title, "description": description, "recommendation": recommendation}


def check_config(text):
    cfg = strip_comments(text)
    findings = []

    if not re.search(r"server_tokens\s+off\s*;", cfg):
        findings.append(finding("NGX_VERSION_EXPOSED", "medium", "未关闭 server_tokens", "可能暴露 Nginx 版本信息。", "在 http/server 块中配置 server_tokens off;"))

    if re.search(r"autoindex\s+on\s*;", cfg):
        findings.append(finding("NGX_AUTOINDEX_ON", "high", "启用了目录浏览", "目录文件可能被列出并泄露。", "配置 autoindex off; 并检查目录权限。"))
    elif not re.search(r"autoindex\s+off\s*;", cfg):
        findings.append(finding("NGX_AUTOINDEX_UNSET", "low", "未显式关闭目录浏览", "依赖默认值不利于基线审计。", "显式配置 autoindex off;"))

    if re.search(r"ssl_protocols[^;]*(TLSv1\s|TLSv1\.1)", cfg):
        findings.append(finding("NGX_WEAK_TLS", "high", "启用了弱 TLS 协议", "TLSv1/TLSv1.1 已不推荐使用。", "仅启用 TLSv1.2 TLSv1.3。"))
    elif "ssl_protocols" not in cfg:
        findings.append(finding("NGX_TLS_UNSET", "medium", "未发现 ssl_protocols", "HTTPS 服务可能未明确限制安全协议版本。", "配置 ssl_protocols TLSv1.2 TLSv1.3;"))

    headers = {
        "X-Frame-Options": "降低点击劫持风险",
        "X-Content-Type-Options": "降低 MIME 嗅探风险",
        "Referrer-Policy": "控制 Referer 泄露",
        "Content-Security-Policy": "降低 XSS 和内容注入风险",
    }
    for h, desc in headers.items():
        if h not in cfg:
            findings.append(finding(f"NGX_MISSING_{h.upper().replace('-', '_')}", "medium", f"缺少安全响应头 {h}", desc, f"使用 add_header 配置 {h}。"))

    # HSTS header (Strict-Transport-Security)
    if "Strict-Transport-Security" not in cfg:
        findings.append(finding("NGX_MISSING_HSTS", "medium", "缺少 HSTS 头", "未启用 HTTP 严格传输安全，可能导致降级攻击。", "配置 add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains\" always;"))

    # OCSP stapling
    if "ssl_stapling" not in cfg and "ssl_certificate" in cfg:
        findings.append(finding("NGX_OCSP_STAPLING_UNSET", "low", "未启用 OCSP Stapling", "TLS 证书吊销检查可能较慢。", "配置 ssl_stapling on; ssl_stapling_verify on;"))

    # proxy_hide_header: hide upstream server info
    if "proxy_pass" in cfg and "proxy_hide_header" not in cfg:
        findings.append(finding("NGX_PROXY_HEADERS_LEAKING", "low", "未隐藏后端响应头", "后端可能通过 Server、X-Powered-By 等头泄露技术栈。", "使用 proxy_hide_header 隐藏后端敏感响应头。"))

    if "client_max_body_size" not in cfg:
        findings.append(finding("NGX_UPLOAD_SIZE_UNSET", "medium", "未限制上传大小", "可能导致大文件上传或资源消耗。", "按业务需要配置 client_max_body_size，例如 10m。"))
    elif re.search(r"client_max_body_size\s+(\d+)m\s*;", cfg):
        size = int(re.search(r"client_max_body_size\s+(\d+)m\s*;", cfg).group(1))
        if size > 50:
            findings.append(finding("NGX_UPLOAD_SIZE_LARGE", "medium", "上传大小限制过大", f"当前限制为 {size}m，可能增加 DoS 风险。", "按业务需要降低上传大小限制。"))

    if "access_log" not in cfg:
        findings.append(finding("NGX_ACCESS_LOG_UNSET", "medium", "未发现访问日志配置", "缺少访问日志会影响审计和溯源。", "配置 access_log 并接入集中日志平台。"))
    if "error_log" not in cfg:
        findings.append(finding("NGX_ERROR_LOG_UNSET", "low", "未发现错误日志配置", "错误日志不足会影响故障定位。", "配置 error_log 并设置合适级别。"))

    if "limit_req" not in cfg:
        findings.append(finding("NGX_RATE_LIMIT_UNSET", "medium", "未发现请求限速配置", "登录、接口和全站入口可能遭受暴力破解或 CC 攻击。", "配置 limit_req_zone 和 limit_req。"))

    if re.search(r"location\s+[^\{]*(backup|bak|\.git|\.env|secret|config)", cfg, re.I):
        findings.append(finding("NGX_SENSITIVE_LOCATION", "high", "疑似敏感 location 暴露", "配置中存在 backup、config、secret 等敏感路径。", "对敏感路径 deny all 或移出 Web 根目录。"))

    if "proxy_pass" in cfg and "X-Real-IP" not in cfg:
        findings.append(finding("NGX_PROXY_HEADERS_INCOMPLETE", "medium", "反向代理头配置不完整", "后端可能无法获得真实客户端 IP，影响审计与访问控制。", "配置 X-Real-IP、X-Forwarded-For、X-Forwarded-Proto。"))

    summary = {"total_findings": len(findings), "high": 0, "medium": 0, "low": 0, "info": 0}
    for f in findings:
        summary[f["severity"]] = summary.get(f["severity"], 0) + 1
    return {"summary": summary, "findings": findings}


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 nginx_security_check.py <nginx.conf> <output.json>")
        sys.exit(1)
    with open(sys.argv[1], encoding="utf-8") as f:
        text = f.read()
    result = check_config(text)
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
